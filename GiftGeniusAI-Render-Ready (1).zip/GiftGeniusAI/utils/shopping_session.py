"""Session helpers for shopping tools — filesystem-backed to avoid large cookies."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from flask import current_app, session

from utils.interview_session import get_interview_state

SHOPPING_KEY = "gift_shopping_meta"
CHAT_KEY = "gift_chat_meta"
STORE_ID_KEY = "gg_store_id"


def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _store_id() -> str:
    sid = session.get(STORE_ID_KEY)
    if not isinstance(sid, str) or len(sid) < 8:
        sid = uuid.uuid4().hex
        session[STORE_ID_KEY] = sid
        session.modified = True
    return sid


def _store_path(kind: str) -> Path:
    root = Path(current_app.instance_path) / "shopping_store"
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{_store_id()}_{kind}.json"


def _read_json(kind: str, default: dict[str, Any]) -> dict[str, Any]:
    path = _store_path(kind)
    if not path.exists():
        return dict(default)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else dict(default)
    except (OSError, json.JSONDecodeError):
        return dict(default)


def _write_json(kind: str, data: dict[str, Any]) -> None:
    path = _store_path(kind)
    path.write_text(json.dumps(data, ensure_ascii=True), encoding="utf-8")


def get_shopping_state() -> dict[str, Any]:
    default = {
        "shops": None,
        "prices": None,
        "checklist": None,
        "wrapping": None,
        "greeting": None,
        "gifts": None,
        "match": None,
        "countdown": None,
        "updated_at": None,
    }
    return _read_json("shopping", default)


def save_shopping_state(state: dict[str, Any]) -> None:
    """Persist shopping payload and keep cookie metadata tiny."""
    compact = dict(state)
    # Compact gifts for storage (drop verbose tags).
    gifts = compact.get("gifts")
    if isinstance(gifts, list):
        compact["gifts"] = [
            {
                "name": g.get("name"),
                "category": g.get("category"),
                "estimated_price": g.get("estimated_price"),
                "why": g.get("why"),
                "score": g.get("score"),
                "match_score": g.get("match_score"),
            }
            for g in gifts
        ]
    # Keep price rows lean for dashboard (full table regenerates cheaply).
    prices = compact.get("prices")
    if isinstance(prices, list):
        lean = []
        for row in prices[:10]:
            lean.append(
                {
                    "gift_name": row.get("gift_name"),
                    "category": row.get("category"),
                    "estimated_price_label": row.get("estimated_price_label"),
                    "lowest_estimate": row.get("lowest_estimate"),
                    "highest_estimate": row.get("highest_estimate"),
                    "average_estimate": row.get("average_estimate"),
                    "discount_percentage_estimate": row.get("discount_percentage_estimate"),
                    "availability": row.get("availability"),
                    "data_note": row.get("data_note"),
                    "is_estimate": True,
                    "shopping_links": (row.get("shopping_links") or [])[:10],
                }
            )
        compact["prices"] = lean

    compact["updated_at"] = utc_now_iso()
    _write_json("shopping", compact)
    session[SHOPPING_KEY] = {"updated_at": compact["updated_at"]}
    session.modified = True


def get_profile_or_empty() -> dict[str, Any]:
    interview = get_interview_state() or {}
    if interview.get("complete") and interview.get("profile"):
        return dict(interview["profile"])
    return {}


def get_chat_memory() -> dict[str, Any]:
    default: dict[str, Any] = {"messages": [], "gifts": []}
    return _read_json("chat", default)


def save_chat_memory(memory: dict[str, Any]) -> None:
    compact = dict(memory)
    messages = list(compact.get("messages") or [])[-20:]
    compact["messages"] = messages
    gifts = compact.get("gifts") or []
    if isinstance(gifts, list):
        compact["gifts"] = [
            {"name": g.get("name"), "estimated_price": g.get("estimated_price")}
            for g in gifts[:10]
            if isinstance(g, dict)
        ]
    _write_json("chat", compact)
    session[CHAT_KEY] = {"count": len(messages)}
    session.modified = True


def append_chat_message(role: str, content: str, limit: int = 20) -> None:
    memory = get_chat_memory()
    messages = list(memory.get("messages") or [])
    messages.append({"role": role, "content": content, "at": utc_now_iso()})
    memory["messages"] = messages[-limit:]
    save_chat_memory(memory)


def sync_chat_gifts(gifts: list[dict[str, Any]]) -> None:
    memory = get_chat_memory()
    memory["gifts"] = gifts
    save_chat_memory(memory)
