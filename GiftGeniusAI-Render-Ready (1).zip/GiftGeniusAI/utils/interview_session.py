"""Session helpers for the gift interview flow."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from flask import session

from agents.interview_agent import InterviewAgent

SESSION_KEY = "gift_interview"


def utc_now_iso() -> str:
    """Return the current UTC timestamp in ISO-8601 format."""
    return datetime.now(UTC).isoformat()


def new_interview_state(opening: str) -> dict[str, Any]:
    """Create a fresh interview session payload."""
    return {
        "started_at": utc_now_iso(),
        "updated_at": utc_now_iso(),
        "current_index": 0,
        "answers": {},
        "acknowledgements": [],
        "opening": opening,
        "complete": False,
        "profile": None,
        "summary": None,
        "completed_at": None,
    }


def get_interview_state() -> dict[str, Any] | None:
    """Load interview state from the Flask session."""
    state = session.get(SESSION_KEY)
    return state if isinstance(state, dict) else None


def save_interview_state(state: dict[str, Any]) -> None:
    """Persist interview state and mark the session as modified."""
    state["updated_at"] = utc_now_iso()
    session[SESSION_KEY] = state
    session.modified = True


def clear_interview_state() -> None:
    """Remove interview data from the session."""
    session.pop(SESSION_KEY, None)
    session.modified = True


def get_search_history() -> list[dict[str, Any]]:
    """Return saved interview briefs for the Search History feature."""
    history = session.get("search_history")
    if not isinstance(history, list):
        return []
    return history


def append_search_history(entry: dict[str, Any], limit: int = 12) -> None:
    """Prepend a completed interview brief to search history."""
    history = get_search_history()
    history.insert(0, entry)
    session["search_history"] = history[:limit]
    session.modified = True


def build_history_entry(result: dict[str, Any]) -> dict[str, Any]:
    """Create a compact history card from a completed interview result."""
    profile = result.get("profile") or {}
    return {
        "saved_at": utc_now_iso(),
        "recipient_name": profile.get("recipient_name"),
        "occasion": profile.get("occasion"),
        "budget": profile.get("budget"),
        "relationship": profile.get("relationship"),
        "summary": result.get("summary"),
    }


def create_agent_from_app(app_extensions: dict[str, Any]) -> InterviewAgent:
    """Construct an InterviewAgent using the app's Ollama client when present."""
    ollama = app_extensions.get("ollama")
    return InterviewAgent(ollama=ollama)
