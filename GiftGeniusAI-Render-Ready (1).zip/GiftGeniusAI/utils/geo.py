"""Geocoding and nearby place helpers (OpenStreetMap / Nominatim / Overpass)."""

from __future__ import annotations

import math
import time
from typing import Any

import requests

from utils.logger import get_logger

logger = get_logger("geo")

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
USER_AGENT = "GiftGeniusAI/1.0 (gift recommendation platform)"


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Return great-circle distance in kilometres between two WGS84 points."""
    radius = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lambda = math.radians(lon2 - lon1)
    a = math.sin(d_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lambda / 2) ** 2
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def estimate_travel_minutes(distance_km: float, mode: str = "driving") -> int:
    """
    Rough travel-time estimate from distance.

    Clearly an estimate — not live traffic routing.
    """
    speeds = {"walking": 5.0, "driving": 25.0, "transit": 18.0}
    speed = speeds.get(mode, 25.0)
    minutes = int(max(1, round((distance_km / speed) * 60)))
    return minutes


def geocode_place(
    *,
    query: str | None = None,
    city: str | None = None,
    state: str | None = None,
    country: str | None = None,
) -> dict[str, Any] | None:
    """
    Geocode a free-text query or city/state/country via Nominatim.

    Returns:
        Dict with lat, lon, display_name — or None on failure.
    """
    parts = [p for p in (city, state, country) if p]
    q = (query or "").strip() or ", ".join(parts)
    if not q:
        return None

    try:
        response = requests.get(
            NOMINATIM_URL,
            params={"q": q, "format": "json", "limit": 1},
            headers={"User-Agent": USER_AGENT},
            timeout=12,
        )
        response.raise_for_status()
        results = response.json()
        if not results:
            return None
        hit = results[0]
        return {
            "lat": float(hit["lat"]),
            "lon": float(hit["lon"]),
            "display_name": hit.get("display_name") or q,
            "query": q,
            "source": "nominatim",
        }
    except (requests.RequestException, ValueError, KeyError, TypeError) as exc:
        logger.warning("Geocode failed for %s: %s", q, exc)
        return None


# OSM tag bundles for gift-related shop categories
CATEGORY_OVERPASS: dict[str, str] = {
    "Gift Shops": 'node["shop"="gift"](around:{radius},{lat},{lon});',
    "Flower Shops": 'node["shop"="florist"](around:{radius},{lat},{lon});',
    "Toy Stores": 'node["shop"="toys"](around:{radius},{lat},{lon});',
    "Book Stores": 'node["shop"="books"](around:{radius},{lat},{lon});',
    "Electronics Stores": (
        'node["shop"~"electronics|computer|mobile_phone"](around:{radius},{lat},{lon});'
    ),
    "Jewellery Stores": 'node["shop"="jewelry"](around:{radius},{lat},{lon});',
    "Handmade Gift Stores": 'node["shop"~"craft|art|handmade"](around:{radius},{lat},{lon});',
    "Fashion Stores": (
        'node["shop"~"clothes|fashion|boutique"](around:{radius},{lat},{lon});'
    ),
    "Cake Shops": 'node["shop"~"bakery|pastry|confectionery"](around:{radius},{lat},{lon});',
    "Chocolate Shops": 'node["shop"~"chocolate|confectionery"](around:{radius},{lat},{lon});',
    "Customized Gift Shops": 'node["shop"~"gift|craft"](around:{radius},{lat},{lon});',
}


def query_nearby_shops(
    lat: float,
    lon: float,
    *,
    radius_m: int = 5000,
    categories: list[str] | None = None,
) -> list[dict[str, Any]]:
    """
    Query Overpass for nearby shop nodes matching gift-related categories.

    Returns:
        List of normalised shop dicts (may be empty if Overpass is unavailable).
    """
    selected = categories or list(CATEGORY_OVERPASS.keys())
    clauses: list[str] = []
    for name in selected:
        template = CATEGORY_OVERPASS.get(name)
        if template:
            clauses.append(
                template.format(radius=radius_m, lat=lat, lon=lon).replace("node", "nwr")
            )

    if not clauses:
        return []

    query = "[out:json][timeout:25];(" + "".join(clauses) + ");out center tags 40;"
    try:
        response = requests.post(
            OVERPASS_URL,
            data={"data": query},
            headers={"User-Agent": USER_AGENT},
            timeout=30,
        )
        response.raise_for_status()
        elements = response.json().get("elements") or []
    except (requests.RequestException, ValueError) as exc:
        logger.warning("Overpass query failed: %s", exc)
        return []

    shops: list[dict[str, Any]] = []
    seen: set[str] = set()
    for el in elements:
        tags = el.get("tags") or {}
        name = tags.get("name")
        if not name:
            continue
        shop_lat = el.get("lat") or (el.get("center") or {}).get("lat")
        shop_lon = el.get("lon") or (el.get("center") or {}).get("lon")
        if shop_lat is None or shop_lon is None:
            continue
        shop_lat_f = float(shop_lat)
        shop_lon_f = float(shop_lon)
        key = f"{name.lower()}|{round(shop_lat_f, 5)}|{round(shop_lon_f, 5)}"
        if key in seen:
            continue
        seen.add(key)

        category = _infer_category(tags)
        distance = haversine_km(lat, lon, shop_lat_f, shop_lon_f)
        address = _format_address(tags)
        maps_query = f"{shop_lat_f},{shop_lon_f}"
        maps_link = f"https://www.google.com/maps/search/?api=1&query={maps_query}"
        directions = (
            "https://www.google.com/maps/dir/?api=1"
            f"&origin={lat},{lon}&destination={shop_lat_f},{shop_lon_f}"
        )
        travel = estimate_travel_minutes(distance, "driving")

        shops.append(
            {
                "name": name,
                "category": category,
                "address": address,
                "distance_km": round(distance, 2),
                "rating": None,
                "rating_label": "Rating unavailable (OpenStreetMap)",
                "opening_hours": tags.get("opening_hours") or "Hours not listed",
                "phone": tags.get("phone") or tags.get("contact:phone") or "Not listed",
                "website": tags.get("website") or tags.get("contact:website") or "",
                "maps_link": maps_link,
                "directions_link": directions,
                "travel_minutes_estimate": travel,
                "lat": shop_lat_f,
                "lon": shop_lon_f,
                "source": "openstreetmap",
                "tier": _tier_for_category(category),
            }
        )

    # Be polite to public OSM endpoints if called repeatedly in-process.
    time.sleep(0.2)
    return shops


def _infer_category(tags: dict[str, str]) -> str:
    shop = (tags.get("shop") or "").lower()
    mapping = {
        "gift": "Gift Shops",
        "florist": "Flower Shops",
        "toys": "Toy Stores",
        "books": "Book Stores",
        "electronics": "Electronics Stores",
        "computer": "Electronics Stores",
        "mobile_phone": "Electronics Stores",
        "jewelry": "Jewellery Stores",
        "craft": "Handmade Gift Stores",
        "art": "Handmade Gift Stores",
        "clothes": "Fashion Stores",
        "fashion": "Fashion Stores",
        "boutique": "Fashion Stores",
        "bakery": "Cake Shops",
        "pastry": "Cake Shops",
        "chocolate": "Chocolate Shops",
        "confectionery": "Chocolate Shops",
    }
    for key, label in mapping.items():
        if key in shop:
            return label
    return "Gift Shops"


def _tier_for_category(category: str) -> str:
    premium = {"Jewellery Stores", "Fashion Stores", "Electronics Stores"}
    budget = {"Toy Stores", "Book Stores", "Chocolate Shops", "Cake Shops"}
    if category in premium:
        return "premium"
    if category in budget:
        return "budget"
    return "mid"


def _format_address(tags: dict[str, str]) -> str:
    parts = [
        tags.get("addr:housenumber"),
        tags.get("addr:street"),
        tags.get("addr:suburb") or tags.get("addr:neighbourhood"),
        tags.get("addr:city") or tags.get("addr:town"),
        tags.get("addr:state"),
        tags.get("addr:postcode"),
    ]
    cleaned = [p for p in parts if p]
    if cleaned:
        return ", ".join(cleaned)
    return tags.get("addr:full") or "Address not listed on OpenStreetMap"
