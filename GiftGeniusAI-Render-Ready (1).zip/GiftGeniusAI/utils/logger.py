"""Centralized logging for GiftGenius AI."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


def setup_logging(log_dir: Path, level: str = "INFO") -> logging.Logger:
    """
    Configure application-wide logging with console and rotating file handlers.

    Args:
        log_dir: Directory where log files are written.
        level: Logging level name (e.g. INFO, DEBUG).

    Returns:
        Configured root application logger.
    """
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "giftgenius.log"

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    logger = logging.getLogger("giftgenius")
    logger.setLevel(numeric_level)
    logger.handlers.clear()
    logger.propagate = False

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=2_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Return a child logger under the giftgenius namespace."""
    return logging.getLogger(f"giftgenius.{name}")
