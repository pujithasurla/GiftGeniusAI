"""Reusable HTTP client for the local Ollama API."""

from __future__ import annotations

from typing import Any

import requests

from utils.logger import get_logger

logger = get_logger("ollama_client")


class OllamaClientError(Exception):
    """Raised when an Ollama request fails."""


class OllamaClient:
    """
    Thin wrapper around the Ollama HTTP API.

    Configuration is provided via constructor arguments so credentials
    and base URLs are never hardcoded at call sites.
    """

    def __init__(
        self,
        base_url: str,
        model: str,
        timeout: int = 120,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def is_available(self) -> bool:
        """Return True if the Ollama server responds to /api/tags."""
        try:
            response = self.session.get(
                f"{self.base_url}/api/tags",
                timeout=2,
            )
            return response.status_code == 200
        except requests.RequestException as exc:
            logger.warning("Ollama availability check failed: %s", exc)
            return False

    def generate(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.7,
        format_json: bool = False,
        timeout: int | None = None,
    ) -> str:
        """
        Generate a completion from the configured Ollama model.

        Args:
            prompt: User / agent prompt text.
            system: Optional system instruction.
            temperature: Sampling temperature.
            format_json: When True, request JSON-formatted output.
            timeout: Optional request timeout override in seconds.

        Returns:
            Model response text.

        Raises:
            OllamaClientError: If the request fails or returns an empty body.
        """
        payload: dict[str, Any] = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        if system:
            payload["system"] = system
        if format_json:
            payload["format"] = "json"

        request_timeout = timeout if timeout is not None else self.timeout

        try:
            response = self.session.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=request_timeout,
            )
            response.raise_for_status()
            data = response.json()
            text = (data.get("response") or "").strip()
            if not text:
                raise OllamaClientError("Ollama returned an empty response.")
            return text
        except requests.Timeout as exc:
            logger.error("Ollama generate timed out: %s", exc)
            raise OllamaClientError("Ollama request timed out.") from exc
        except requests.RequestException as exc:
            logger.error("Ollama generate failed: %s", exc)
            raise OllamaClientError(f"Ollama request failed: {exc}") from exc

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        temperature: float = 0.7,
    ) -> str:
        """
        Run a multi-turn chat completion against Ollama.

        Args:
            messages: List of {"role": "...", "content": "..."} dicts.
            temperature: Sampling temperature.

        Returns:
            Assistant message content.

        Raises:
            OllamaClientError: If the request fails.
        """
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature},
        }

        try:
            response = self.session.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=self.timeout,
            )
            response.raise_for_status()
            data = response.json()
            message = data.get("message") or {}
            content = (message.get("content") or "").strip()
            if not content:
                raise OllamaClientError("Ollama chat returned an empty message.")
            return content
        except requests.Timeout as exc:
            logger.error("Ollama chat timed out: %s", exc)
            raise OllamaClientError("Ollama chat timed out.") from exc
        except requests.RequestException as exc:
            logger.error("Ollama chat failed: %s", exc)
            raise OllamaClientError(f"Ollama chat failed: {exc}") from exc
