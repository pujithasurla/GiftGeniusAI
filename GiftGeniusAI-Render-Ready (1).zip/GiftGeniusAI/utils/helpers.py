"""Reusable helper utilities for GiftGenius AI."""

from __future__ import annotations

from typing import Any


def format_currency(amount: float | int, currency: str = "INR") -> str:
    """
    Format a numeric amount as a localized currency string.

    Args:
        amount: Monetary value.
        currency: ISO currency code (currently INR-focused).

    Returns:
        Formatted currency string.
    """
    try:
        value = float(amount)
    except (TypeError, ValueError):
        return str(amount)

    if currency.upper() == "INR":
        return f"₹{value:,.0f}"
    return f"{currency.upper()} {value:,.2f}"


def safe_int(value: Any, default: int = 0) -> int:
    """Convert a value to int, returning default on failure."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def clamp(value: float, minimum: float = 0.0, maximum: float = 100.0) -> float:
    """Clamp a numeric value into an inclusive range."""
    return max(minimum, min(maximum, float(value)))


def truncate_text(text: str, max_length: int = 120, suffix: str = "…") -> str:
    """
    Truncate text to a maximum length with an optional suffix.

    Args:
        text: Source string.
        max_length: Maximum characters including the suffix.
        suffix: Trailing marker when truncation occurs.

    Returns:
        Truncated string.
    """
    cleaned = (text or "").strip()
    if len(cleaned) <= max_length:
        return cleaned
    cut = max_length - len(suffix)
    return cleaned[:cut].rstrip() + suffix
