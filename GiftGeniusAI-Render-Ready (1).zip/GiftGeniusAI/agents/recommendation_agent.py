"""Recommendation Agent — generate ranked gift ideas from an interview profile."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class RecommendationAgent(BaseAgent):
    """Produce practical top gift ideas from a recipient profile (no ML)."""

    name = "recommendation"

    CATALOG: tuple[dict[str, Any], ...] = (
        {
            "name": "Personalized Photo Book",
            "category": "Personalized",
            "base_price": 1200,
            "tags": ["personalized", "books", "memory", "birthday", "anniversary"],
        },
        {
            "name": "Noise-Cancelling Earbuds",
            "category": "Technology",
            "base_price": 4500,
            "tags": ["technology", "electronics", "music", "practical", "premium"],
        },
        {
            "name": "Artisan Chocolate Hamper",
            "category": "Food",
            "base_price": 900,
            "tags": ["food", "chocolate", "festival", "valentine", "birthday"],
        },
        {
            "name": "Leather Journal & Pen Set",
            "category": "Books",
            "base_price": 1100,
            "tags": ["books", "practical", "professional", "graduation"],
        },
        {
            "name": "Handmade Ceramic Mug Set",
            "category": "Handmade",
            "base_price": 850,
            "tags": ["handmade", "home", "coffee", "birthday"],
        },
        {
            "name": "Smart Fitness Band",
            "category": "Technology",
            "base_price": 2800,
            "tags": ["technology", "fitness", "health", "practical"],
        },
        {
            "name": "Silk Scarf",
            "category": "Fashion",
            "base_price": 1800,
            "tags": ["fashion", "luxury", "elegant", "anniversary"],
        },
        {
            "name": "Custom Name Necklace",
            "category": "Jewellery",
            "base_price": 2200,
            "tags": ["jewellery", "personalized", "romantic", "valentine"],
        },
        {
            "name": "Indoor Plant Pair with Pot",
            "category": "Home",
            "base_price": 999,
            "tags": ["home", "gardening", "housewarming", "practical"],
        },
        {
            "name": "Bluetooth Portable Speaker",
            "category": "Electronics",
            "base_price": 2500,
            "tags": ["electronics", "music", "technology", "party"],
        },
        {
            "name": "Gourmet Coffee Tasting Kit",
            "category": "Food",
            "base_price": 1300,
            "tags": ["food", "coffee", "practical", "colleague"],
        },
        {
            "name": "DIY Candle Making Kit",
            "category": "Handmade",
            "base_price": 750,
            "tags": ["handmade", "creative", "diy", "kids"],
        },
    )

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(self, profile: dict[str, Any], *, limit: int = 10) -> list[dict[str, Any]]:
        """Rank catalog gifts against the interview profile and return top N."""
        budget = profile.get("budget")
        try:
            budget_i = int(budget) if budget is not None else None
        except (TypeError, ValueError):
            budget_i = None

        interests = [str(i).lower() for i in (profile.get("interests") or [])]
        gift_types = [str(i).lower() for i in (profile.get("gift_types") or [])]
        occasion = str(profile.get("occasion") or "").lower()
        surprise = str(profile.get("surprise_level") or "").lower()
        hobbies = str(profile.get("hobbies") or "").lower()
        favorites = profile.get("favorites") or {}

        scored: list[dict[str, Any]] = []
        for item in self.CATALOG:
            score = 50
            tags = item["tags"]
            text = " ".join(tags)
            for interest in interests:
                if interest and interest in text:
                    score += 8
            for gt in gift_types:
                if gt and (gt in text or gt in item["category"].lower()):
                    score += 10
            if occasion and occasion.split()[0] in text:
                score += 8
            if surprise == "premium" and item["base_price"] >= 2000:
                score += 6
            if surprise == "simple" and item["base_price"] <= 1500:
                score += 6
            if surprise == "creative" and ("handmade" in text or "diy" in text):
                score += 7
            if hobbies and any(h in hobbies for h in tags):
                score += 5
            for fav in favorites.values():
                if fav and str(fav).lower() in text:
                    score += 4

            price = item["base_price"]
            if budget_i:
                if price <= budget_i:
                    score += 12
                elif price <= budget_i * 1.15:
                    score += 4
                else:
                    score -= 15
                # Soft-fit price toward budget mid.
                price = min(price, budget_i)

            scored.append(
                {
                    "name": item["name"],
                    "category": item["category"],
                    "estimated_price": price,
                    "tags": tags,
                    "why": self._why(item, profile),
                    "score": score,
                }
            )

        scored.sort(key=lambda g: g["score"], reverse=True)
        top = scored[:limit]
        self.logger.info("Generated %s gift recommendations", len(top))
        return top

    def _why(self, item: dict[str, Any], profile: dict[str, Any]) -> str:
        who = profile.get("recipient_name") or "them"
        occasion = profile.get("occasion") or "the occasion"
        return (
            f"{item['name']} suits {who} for {occasion}, "
            f"aligning with {item['category'].lower()} preferences."
        )
