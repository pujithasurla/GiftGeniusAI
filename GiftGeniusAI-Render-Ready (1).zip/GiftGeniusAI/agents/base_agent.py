"""Shared base class for GiftGenius AI agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from utils.logger import get_logger
from utils.ollama_client import OllamaClient, OllamaClientError


class BaseAgent(ABC):
    """Abstract base for all specialised gift agents."""

    name: str = "base"

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        self.ollama = ollama
        self.logger = get_logger(f"agents.{self.name}")

    def ask_ollama(
        self,
        prompt: str,
        *,
        system: str | None = None,
        temperature: float = 0.6,
        fallback: str = "",
        timeout: int | None = None,
    ) -> str:
        """
        Call Ollama safely, returning fallback text when the model is unavailable.

        Args:
            prompt: User / task prompt.
            system: Optional system instruction.
            temperature: Sampling temperature.
            fallback: Text returned when Ollama fails or is not configured.
            timeout: Optional per-call timeout override in seconds.

        Returns:
            Model output or fallback string.
        """
        if self.ollama is None:
            self.logger.debug("%s: Ollama client not configured; using fallback.", self.name)
            return fallback

        if not self.ollama.is_available():
            self.logger.debug("%s: Ollama offline; using fallback.", self.name)
            return fallback

        try:
            return self.ollama.generate(
                prompt,
                system=system,
                temperature=temperature,
                timeout=timeout,
            )
        except OllamaClientError as exc:
            self.logger.warning("%s: Ollama call failed (%s); using fallback.", self.name, exc)
            return fallback

    @abstractmethod
    def run(self, *args: Any, **kwargs: Any) -> Any:
        """Execute the agent's primary responsibility."""
