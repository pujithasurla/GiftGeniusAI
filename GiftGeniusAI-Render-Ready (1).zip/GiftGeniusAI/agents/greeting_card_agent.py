"""Personalized Greeting Card Agent — generate short/medium/long messages."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class GreetingCardAgent(BaseAgent):
    """Generate tone-aware greeting messages for common occasions."""

    name = "greeting_card"

    TONES = (
        "Birthday Wishes",
        "Wedding Wishes",
        "Anniversary Wishes",
        "Graduation Wishes",
        "Festival Wishes",
        "Romantic Messages",
        "Funny Messages",
        "Professional Messages",
    )

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        *,
        tone: str,
        recipient_name: str | None = None,
        occasion: str | None = None,
        relationship: str | None = None,
        sender_name: str | None = None,
    ) -> dict[str, Any]:
        """Return short, medium, and long greeting versions."""
        who = recipient_name or "friend"
        occ = occasion or tone.replace(" Wishes", "").replace(" Messages", "")
        rel = relationship or "someone special"
        sender = sender_name or "Me"

        short, medium, long_msg = self._templates(tone, who, occ, rel, sender)
        polished = self.ask_ollama(
            (
                f"Rewrite this greeting in a warm natural voice, keep under 60 words, "
                f"no emojis:\n{medium}"
            ),
            system="You write gift-card messages. Stay sincere and concise.",
            timeout=12,
            fallback=medium,
        )

        return {
            "tone": tone if tone in self.TONES else "Birthday Wishes",
            "recipient_name": who,
            "occasion": occ,
            "short": short,
            "medium": polished.strip() or medium,
            "long": long_msg,
            "sender_name": sender,
        }

    def _templates(
        self,
        tone: str,
        who: str,
        occ: str,
        rel: str,
        sender: str,
    ) -> tuple[str, str, str]:
        tone_l = tone.lower()
        if "wedding" in tone_l:
            short = f"Wishing you both a lifetime of love, {who}."
            medium = (
                f"Dear {who}, congratulations on your wedding. "
                f"May your new chapter be filled with kindness, laughter, and lasting partnership. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nOn your wedding day, I am so happy for you and your partner. "
                f"May you build a home full of patience, joy, and shared adventures. "
                f"Congratulations from the heart.\n\nWith love,\n{sender}"
            )
        elif "anniversary" in tone_l:
            short = f"Happy anniversary, {who} — here's to more beautiful years."
            medium = (
                f"Happy anniversary, {who}. Your story together is a reminder of what steady love looks like. "
                f"Wishing you another year of warmth and wonderful memories. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nHappy anniversary. Watching your relationship grow has been inspiring. "
                f"May this year bring deeper friendship, fresh adventures, and quiet moments you both treasure.\n\n"
                f"With warm wishes,\n{sender}"
            )
        elif "graduation" in tone_l:
            short = f"Congrats, {who} — you did it!"
            medium = (
                f"Congratulations on your graduation, {who}! Your hard work deserves this spotlight. "
                f"Excited to see what you build next. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nGraduation is more than a ceremony — it is proof of your persistence. "
                f"I am proud of you and cannot wait to watch your next chapter unfold.\n\n"
                f"Celebrate well,\n{sender}"
            )
        elif "festival" in tone_l:
            short = f"Warm festival wishes, {who}!"
            medium = (
                f"Dear {who}, wishing you a joyful {occ} filled with light, good food, and people you love. "
                f"— {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nAs {occ} arrives, I hope your home feels full and your days feel easy. "
                f"May this season bring peace, prosperity, and time with the people who matter most.\n\n"
                f"Warm regards,\n{sender}"
            )
        elif "romantic" in tone_l:
            short = f"{who}, you make ordinary days feel extraordinary."
            medium = (
                f"My dearest {who}, thank you for the way you love, laugh, and stay. "
                f"I chose this gift the way I choose you — thoughtfully, and with all my heart. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nEvery version of us is my favourite. "
                f"This gift is a small symbol of a much larger feeling — gratitude for your kindness, "
                f"and excitement for everything still ahead.\n\nYours,\n{sender}"
            )
        elif "funny" in tone_l:
            short = f"{who}, you’re hard to shop for — so I overachieved."
            medium = (
                f"Happy {occ}, {who}! I considered getting you something sensible… "
                f"then remembered you’re my {rel}. Enjoy this highly official gift. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nI put more thought into this gift than I put into assembling furniture. "
                f"May it bring smiles, snacks, and at least one unnecessary selfie.\n\n"
                f"Affectionately ridiculous,\n{sender}"
            )
        elif "professional" in tone_l:
            short = f"Congratulations, {who}. Wishing you continued success."
            medium = (
                f"Dear {who}, congratulations on your {occ}. "
                f"Your dedication is clear, and I wish you every success ahead. — {sender}"
            )
            long_msg = (
                f"Dear {who},\n\nPlease accept my warm congratulations on your {occ}. "
                f"It has been a pleasure to witness your professionalism and growth. "
                f"Wishing you excellence in all that follows.\n\nBest regards,\n{sender}"
            )
        else:
            short = f"Happy {occ}, {who}!"
            medium = (
                f"Happy {occ}, {who}! Hope your day feels as wonderful as you are. "
                f"With love from your {rel}, {sender}."
            )
            long_msg = (
                f"Dear {who},\n\nHappy {occ}! I hope this year brings you health, courage, "
                f"and plenty of reasons to smile. Thank you for being such a meaningful part of my life.\n\n"
                f"With love,\n{sender}"
            )
        return short, medium, long_msg
