"""Gift Wrapping Design Agent — themes, materials, DIY guide, cost estimate."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class WrappingAgent(BaseAgent):
    """Recommend gift-wrapping designs and DIY instructions by theme."""

    name = "wrapping"

    THEMES: dict[str, dict[str, Any]] = {
        "Birthday": {
            "paper": "Warm coral with soft confetti pattern",
            "ribbon": "Pine green satin",
            "bow": "Classic double loop bow",
            "tag": "Handwritten name tag with age accents",
            "card": "Bright birthday card with short warm note",
            "accessories": ["Mini balloon twine", "Confetti sprinkle"],
            "palette": ["#c45c4a", "#0f5c4c", "#f3f5f2"],
        },
        "Wedding": {
            "paper": "Ivory linen-texture wrap",
            "ribbon": "Champagne organza",
            "bow": "Soft flat bow with long tails",
            "tag": "Calligraphy initials tag",
            "card": "Elegant cream card with formal wishes",
            "accessories": ["Dried baby's breath", "Wax seal sticker"],
            "palette": ["#f7f2ea", "#c9b79c", "#5b5248"],
        },
        "Kids": {
            "paper": "Playful animal or star wrap",
            "ribbon": "Sunny yellow grosgrain",
            "bow": "Big fluffy boutique bow",
            "tag": "Cartoon sticker tag",
            "card": "Fun illustrated kids card",
            "accessories": ["Sticker sheet", "Colourful tissue fill"],
            "palette": ["#f2c94c", "#2f80ed", "#eb5757"],
        },
        "Elegant": {
            "paper": "Matte charcoal kraft",
            "ribbon": "Soft gold ribbon",
            "bow": "Minimal single-loop bow",
            "tag": "Black letterpress-style tag",
            "card": "Understated monochrome card",
            "accessories": ["Sprig of eucalyptus"],
            "palette": ["#2a2a2a", "#c2a878", "#f4f4f4"],
        },
        "Luxury": {
            "paper": "Deep emerald foil wrap",
            "ribbon": "Velvet burgundy ribbon",
            "bow": "Structured layered bow",
            "tag": "Metallic foil name tag",
            "card": "Premium folded card with embossed edge",
            "accessories": ["Fairy lights (battery)", "Personalized sticker"],
            "palette": ["#0f5c4c", "#7a1f2b", "#d4af37"],
        },
        "Minimal": {
            "paper": "Unbleached kraft paper",
            "ribbon": "Thin black cotton twine",
            "bow": "Simple knot (no bow)",
            "tag": "Plain white rectangle tag",
            "card": "Minimal line-art card",
            "accessories": ["Single dried leaf"],
            "palette": ["#d9cfc0", "#222222", "#ffffff"],
        },
        "Festival": {
            "paper": "Festive motif wrap with warm metallics",
            "ribbon": "Maroon and gold duo ribbon",
            "bow": "Full festive bow",
            "tag": "Occasion motif tag",
            "card": "Festival greeting card",
            "accessories": ["Flowers", "Lights", "Personalized sticker"],
            "palette": ["#7a1f2b", "#d4af37", "#0f5c4c"],
        },
        "Christmas": {
            "paper": "Forest green or soft snowflake wrap",
            "ribbon": "Classic red ribbon",
            "bow": "Full Christmas bow",
            "tag": "North-pole style gift tag",
            "card": "Christmas greeting card",
            "accessories": ["Pine sprig", "Mini ornament"],
            "palette": ["#0f5c4c", "#b33a3a", "#f7f2ea"],
        },
        "Valentine": {
            "paper": "Blush or soft berry wrap",
            "ribbon": "Satin rose ribbon",
            "bow": "Romantic heart-centered bow",
            "tag": "Heart gift tag",
            "card": "Romantic note card",
            "accessories": ["Dried rose petal", "Scented sticker"],
            "palette": ["#c45c4a", "#f3d6d0", "#5c2a2a"],
        },
        "Baby Shower": {
            "paper": "Pastel cloud wrap",
            "ribbon": "Soft mint ribbon",
            "bow": "Soft chiffon bow",
            "tag": "Tiny feet motif tag",
            "card": "Gentle baby shower card",
            "accessories": ["Tissue pompoms"],
            "palette": ["#b7d7c8", "#f7e7d0", "#f3f5f2"],
        },
    }

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def available_themes(self) -> list[str]:
        """Return supported wrapping themes."""
        return list(self.THEMES.keys())

    def run(
        self,
        theme: str,
        *,
        recipient_name: str | None = None,
        occasion: str | None = None,
    ) -> dict[str, Any]:
        """Generate wrapping recommendation, DIY guide, and cost estimate."""
        key = theme if theme in self.THEMES else self._theme_from_occasion(occasion)
        design = dict(self.THEMES[key])
        who = recipient_name or "them"
        instructions = [
            "Measure and cut wrapping paper with a 5–7 cm overlap on each side.",
            "Fold clean edges; tape the seam on the underside.",
            f"Wrap with {design['paper'].lower()}.",
            f"Tie {design['ribbon'].lower()} and finish with a {design['bow'].lower()}.",
            f"Attach {design['tag'].lower()} addressed to {who}.",
            f"Pair with {design['card'].lower()}.",
            "Add accessories last so they sit neatly without crushing the bow.",
        ]
        diy = [
            "Use double-sided tape for a cleaner finish.",
            "Crease corners with a bone folder or spoon edge for sharp lines.",
            "Pre-cut ribbon lengths before tying to keep proportions consistent.",
            "If paper tears, patch from the inside with a matching scrap.",
        ]
        accessories_cost = 40 * len(design.get("accessories") or [])
        estimated_cost = 210 + accessories_cost

        narrative = self.ask_ollama(
            f"In 2 sentences, describe a {key} gift wrap for {who}"
            f"{f' for {occasion}' if occasion else ''}.",
            system="You are a concise gift-wrapping stylist. No emojis.",
            timeout=10,
            fallback=(
                f"A {key.lower()} wrap for {who}: {design['paper'].lower()}, "
                f"finished with {design['ribbon'].lower()} and a {design['bow'].lower()}."
            ),
        )

        return {
            "theme": key,
            "preview": {
                "paper_color": design["paper"],
                "ribbon_color": design["ribbon"],
                "bow_style": design["bow"],
                "gift_tag": design["tag"],
                "greeting_card_style": design["card"],
                "decoration_accessories": design["accessories"],
                "palette": design["palette"],
                "narrative": narrative,
            },
            "wrapping_instructions": instructions,
            "diy_guide": diy,
            "estimated_wrapping_cost": estimated_cost,
            "data_note": "Wrapping cost is a planning estimate for common retail supplies.",
        }

    def _theme_from_occasion(self, occasion: str | None) -> str:
        if not occasion:
            return "Minimal"
        occ = occasion.lower()
        mapping = [
            ("wedding", "Wedding"),
            ("valentine", "Valentine"),
            ("christmas", "Christmas"),
            ("baby", "Baby Shower"),
            ("birthday", "Birthday"),
            ("festival", "Festival"),
            ("diwali", "Festival"),
            ("anniversary", "Elegant"),
        ]
        for needle, theme in mapping:
            if needle in occ:
                return theme
        return "Elegant"
