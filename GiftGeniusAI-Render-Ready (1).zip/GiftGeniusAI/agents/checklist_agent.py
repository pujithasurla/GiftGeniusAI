"""Shopping Checklist Agent — generate, save, and export gift shopping checklists."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class ChecklistAgent(BaseAgent):
    """Build a practical shopping checklist around a gift recommendation."""

    name = "checklist"

    BASE_ITEMS: tuple[tuple[str, int, int, bool], ...] = (
        # item, qty, estimated_cost, always_include
        ("Gift Item", 1, 0, True),
        ("Gift Box", 1, 80, True),
        ("Gift Wrapping Paper", 1, 60, True),
        ("Ribbon", 1, 40, True),
        ("Greeting Card", 1, 50, True),
        ("Gift Bag", 1, 70, False),
        ("Gift Tag", 1, 20, True),
        ("Flowers", 1, 300, False),
        ("Chocolate", 1, 200, False),
        ("Battery (if required)", 1, 120, False),
        ("Accessories", 1, 150, False),
        ("Decoration Items", 1, 100, False),
        ("Gift Receipt", 1, 0, True),
    )

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        *,
        gift_name: str | None = None,
        gift_cost: int | None = None,
        occasion: str | None = None,
        include_extras: bool = True,
    ) -> dict[str, Any]:
        """Generate a checklist with quantities, cost estimates, and pending status."""
        items: list[dict[str, Any]] = []
        for name, qty, cost, always in self.BASE_ITEMS:
            if not always and not include_extras:
                continue
            if name in {"Flowers", "Chocolate"} and occasion:
                occ = occasion.lower()
                if name == "Flowers" and occ not in {
                    "valentine's day",
                    "anniversary",
                    "wedding",
                    "birthday",
                    "mother's day",
                }:
                    if not include_extras:
                        continue
            estimated = gift_cost if name == "Gift Item" and gift_cost else cost
            label = gift_name if name == "Gift Item" and gift_name else name
            items.append(
                {
                    "id": f"item_{len(items)+1}",
                    "item": label if name == "Gift Item" else name,
                    "quantity": qty,
                    "estimated_cost": int(estimated or 0),
                    "status": "pending",
                    "purchased": False,
                }
            )

        total = sum(i["estimated_cost"] * i["quantity"] for i in items)
        return {
            "title": f"Shopping checklist{f' for {gift_name}' if gift_name else ''}",
            "occasion": occasion,
            "items": items,
            "estimated_total": total,
            "data_note": "Costs are planning estimates. Update after you check live prices.",
        }

    def apply_checks(
        self,
        checklist: dict[str, Any],
        purchased_ids: list[str],
    ) -> dict[str, Any]:
        """Update purchased/pending flags from checkbox IDs."""
        purchased_set = set(purchased_ids)
        items = []
        for item in checklist.get("items") or []:
            copy = dict(item)
            is_bought = copy.get("id") in purchased_set
            copy["purchased"] = is_bought
            copy["status"] = "purchased" if is_bought else "pending"
            items.append(copy)
        checklist = dict(checklist)
        checklist["items"] = items
        checklist["estimated_total"] = sum(
            i["estimated_cost"] * i["quantity"] for i in items
        )
        return checklist

    def to_plaintext(self, checklist: dict[str, Any]) -> str:
        """Render a printable/downloadable text checklist."""
        lines = [
            checklist.get("title") or "Shopping Checklist",
            f"Occasion: {checklist.get('occasion') or 'n/a'}",
            f"Estimated total: ₹{checklist.get('estimated_total', 0):,}",
            "",
            f"{'Status':<12}{'Qty':<6}{'Cost':<10}Item",
            "-" * 56,
        ]
        for item in checklist.get("items") or []:
            status = "DONE" if item.get("purchased") else "PENDING"
            lines.append(
                f"{status:<12}{item.get('quantity', 1):<6}"
                f"₹{item.get('estimated_cost', 0):<9}{item.get('item')}"
            )
        lines.append("")
        lines.append(checklist.get("data_note") or "")
        return "\n".join(lines)
