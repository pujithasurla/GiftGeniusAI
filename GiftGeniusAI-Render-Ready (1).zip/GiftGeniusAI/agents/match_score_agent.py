"""Gift Match Score Agent — multi-dimensional compatibility scoring."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.helpers import clamp
from utils.ollama_client import OllamaClient


class MatchScoreAgent(BaseAgent):
    """Calculate an overall gift match score with transparent breakdowns."""

    name = "match_score"

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        profile: dict[str, Any],
        gift: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Score how well a gift (or overall brief) matches the recipient profile.

        When no gift is supplied, scores the completeness/quality of the interview brief.
        """
        interests = [str(i).lower() for i in (profile.get("interests") or [])]
        gift_types = [str(i).lower() for i in (profile.get("gift_types") or [])]
        budget = profile.get("budget")
        occasion = str(profile.get("occasion") or "").lower()
        age = profile.get("age")
        surprise = str(profile.get("surprise_level") or "").lower()

        gift = gift or {}
        gift_name = str(gift.get("name") or gift.get("title") or "").lower()
        gift_cats = [
            str(c).lower()
            for c in (gift.get("categories") or gift.get("gift_types") or gift_types)
        ]
        gift_price = gift.get("estimated_price") or gift.get("average_estimate")

        interest_score = self._interest_score(interests, gift_name, gift_cats, profile)
        budget_score = self._budget_score(budget, gift_price)
        occasion_score = self._occasion_score(occasion, gift_name, gift_cats)
        age_score = self._age_score(age, gift_cats)
        creativity = self._creativity_score(surprise, gift_cats, gift_name)
        practical = self._practical_score(gift_cats, gift_types)

        weights = {
            "recipient_interest": 0.22,
            "budget_match": 0.18,
            "occasion_match": 0.18,
            "age_compatibility": 0.14,
            "creativity": 0.14,
            "practical_value": 0.14,
        }
        breakdown = {
            "recipient_interest": round(interest_score),
            "budget_match": round(budget_score),
            "occasion_match": round(occasion_score),
            "age_compatibility": round(age_score),
            "creativity": round(creativity),
            "practical_value": round(practical),
        }
        overall = sum(breakdown[k] * weights[k] for k in weights)
        overall = round(clamp(overall, 0, 100))

        return {
            "overall": overall,
            "label": self.quality_label(overall),
            "color": self.quality_color(overall),
            "breakdown": breakdown,
            "gift_name": gift.get("name") or gift.get("title") or "Your gift brief",
        }

    def score_gifts(
        self,
        profile: dict[str, Any],
        gifts: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Attach match scores to a list of gifts."""
        scored = []
        for gift in gifts:
            result = self.run(profile, gift)
            enriched = dict(gift)
            enriched["match_score"] = result
            scored.append(enriched)
        return scored

    @staticmethod
    def quality_label(score: float) -> str:
        if score >= 85:
            return "Excellent"
        if score >= 70:
            return "Good"
        return "Average"

    @staticmethod
    def quality_color(score: float) -> str:
        if score >= 85:
            return "#0f5c4c"
        if score >= 70:
            return "#c45c4a"
        return "#8a7a3a"

    def _interest_score(
        self,
        interests: list[str],
        gift_name: str,
        gift_cats: list[str],
        profile: dict[str, Any],
    ) -> float:
        if not interests and not profile.get("hobbies"):
            return 78.0
        haystack = " ".join([gift_name, *gift_cats, str(profile.get("hobbies") or "").lower()])
        hits = sum(1 for i in interests if i and i in haystack)
        if interests:
            return clamp(70 + (hits / max(len(interests), 1)) * 30, 55, 100)
        return 82.0

    def _budget_score(self, budget: Any, gift_price: Any) -> float:
        if not budget:
            return 75.0
        try:
            budget_i = int(budget)
        except (TypeError, ValueError):
            return 75.0
        if gift_price is None:
            return 88.0
        try:
            price = float(gift_price)
        except (TypeError, ValueError):
            return 80.0
        ratio = price / max(budget_i, 1)
        if ratio <= 1.0:
            return clamp(100 - abs(0.75 - ratio) * 20, 80, 100)
        if ratio <= 1.2:
            return 72.0
        return clamp(55 - (ratio - 1.2) * 30, 40, 70)

    def _occasion_score(self, occasion: str, gift_name: str, gift_cats: list[str]) -> float:
        if not occasion:
            return 76.0
        text = " ".join([occasion, gift_name, *gift_cats])
        boosts = {
            "wedding": ["elegant", "jewellery", "personalized", "luxury"],
            "birthday": ["fun", "personal", "creative", "hobby"],
            "anniversary": ["romantic", "jewellery", "experience", "luxury"],
            "graduation": ["practical", "books", "technology", "career"],
            "christmas": ["festive", "family", "toys", "chocolate"],
            "valentine": ["romantic", "flowers", "chocolate", "jewellery"],
        }
        score = 86.0
        for key, words in boosts.items():
            if key in occasion:
                if any(w in text for w in words):
                    score = 96.0
                else:
                    score = 88.0
                break
        return score

    def _age_score(self, age: Any, gift_cats: list[str]) -> float:
        try:
            age_i = int(age)
        except (TypeError, ValueError):
            return 84.0
        kids = any(c in {"toys", "kids", "children"} for c in gift_cats)
        if age_i < 13 and kids:
            return 97.0
        if age_i < 13 and not kids:
            return 68.0
        if age_i >= 13 and kids:
            return 62.0
        return 94.0

    def _creativity_score(
        self,
        surprise: str,
        gift_cats: list[str],
        gift_name: str,
    ) -> float:
        creative_tokens = {"handmade", "personalized", "custom", "creative", "diy", "art"}
        hits = sum(1 for t in creative_tokens if t in gift_name or any(t in c for c in gift_cats))
        base = 78 + hits * 6
        if surprise == "creative":
            base += 8
        elif surprise == "premium":
            base += 5
        elif surprise == "simple":
            base -= 4
        return clamp(base, 55, 100)

    def _practical_score(self, gift_cats: list[str], preferred: list[str]) -> float:
        practical = {"practical", "technology", "electronics", "books", "accessories", "home"}
        score = 80.0
        if any(p in practical for p in preferred):
            score += 8
        if any(any(p in c for p in practical) for c in gift_cats):
            score += 8
        return clamp(score, 60, 100)
