"""Online Price Comparison Agent — estimated ranges + shopping search links."""

from __future__ import annotations

import hashlib
from typing import Any
from urllib.parse import quote_plus

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class PriceComparisonAgent(BaseAgent):
    """
    Compare estimated online prices across popular Indian shopping platforms.

    Live marketplace APIs are not configured. Results use transparent AI/heuristic
    estimate ranges and deep-link search URLs — never fabricated exact prices.
    """

    name = "price_comparison"

    PLATFORMS: tuple[dict[str, str], ...] = (
        {"id": "amazon", "name": "Amazon", "search": "https://www.amazon.in/s?k={q}"},
        {"id": "flipkart", "name": "Flipkart", "search": "https://www.flipkart.com/search?q={q}"},
        {"id": "myntra", "name": "Myntra", "search": "https://www.myntra.com/{q}"},
        {"id": "ajio", "name": "Ajio", "search": "https://www.ajio.com/search/?text={q}"},
        {"id": "firstcry", "name": "FirstCry", "search": "https://www.firstcry.com/search?q={q}"},
        {"id": "nykaa", "name": "Nykaa", "search": "https://www.nykaa.com/search/result/?q={q}"},
        {"id": "croma", "name": "Croma", "search": "https://www.croma.com/searchB?q={q}"},
        {
            "id": "reliance_digital",
            "name": "Reliance Digital",
            "search": "https://www.reliancedigital.in/search?q={q}",
        },
        {"id": "meesho", "name": "Meesho", "search": "https://www.meesho.com/search?q={q}"},
        {
            "id": "local",
            "name": "Local Online Stores",
            "search": "https://www.google.com/search?q={q}+buy+online+india",
        },
    )

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        gifts: list[dict[str, Any]],
        *,
        budget: int | None = None,
    ) -> list[dict[str, Any]]:
        """Build price comparison cards for each gift idea."""
        results: list[dict[str, Any]] = []
        for gift in gifts:
            results.append(self.compare_gift(gift, budget=budget))
        return results

    def compare_gift(
        self,
        gift: dict[str, Any],
        *,
        budget: int | None = None,
    ) -> dict[str, Any]:
        """Produce estimated price band + platform search rows for one gift."""
        name = str(gift.get("name") or gift.get("title") or "Gift").strip()
        category = str(gift.get("category") or gift.get("gift_type") or "general")
        low, high, average = self._estimate_range(name, category, budget)

        platforms: list[dict[str, Any]] = []
        for index, platform in enumerate(self.PLATFORMS):
            # Spread estimates slightly per platform without inventing a "true" price.
            spread = ((index % 5) - 2) * 0.03
            mid = int(average * (1 + spread))
            est_low = max(99, int(mid * 0.9))
            est_high = int(mid * 1.12)
            discount_est = max(0, min(35, int(8 + (index % 4) * 3)))
            delivery = ["1–2 days", "2–4 days", "3–5 days", "4–6 days"][index % 4]
            platforms.append(
                {
                    "platform": platform["name"],
                    "platform_id": platform["id"],
                    "price_estimate_low": est_low,
                    "price_estimate_high": est_high,
                    "price_label": f"₹{est_low:,}–₹{est_high:,} (estimate)",
                    "discount_estimate_pct": discount_est,
                    "discount_label": f"~{discount_est}% off (estimate)",
                    "delivery_estimate": delivery,
                    "availability": "Check live on site",
                    "url": platform["search"].format(q=quote_plus(name)),
                    "is_estimate": True,
                }
            )

        # Badge by relative estimate midpoints — still clearly estimates.
        by_mid = sorted(
            platforms,
            key=lambda p: (p["price_estimate_low"] + p["price_estimate_high"]) / 2,
        )
        lowest_id = by_mid[0]["platform_id"]
        best_value_id = sorted(
            platforms,
            key=lambda p: (
                (p["price_estimate_low"] + p["price_estimate_high"]) / 2,
                -p["discount_estimate_pct"],
            ),
        )[0]["platform_id"]
        fast_id = sorted(
            platforms,
            key=lambda p: (0 if "1–2" in p["delivery_estimate"] else 1, p["platform"]),
        )[0]["platform_id"]

        for row in platforms:
            badges: list[str] = []
            if row["platform_id"] == lowest_id:
                badges.append("Lowest Price")
            if row["platform_id"] == best_value_id:
                badges.append("Best Value")
            if row["platform_id"] == fast_id:
                badges.append("Fast Delivery")
            row["badges"] = badges

        discount_pct = None
        if high > low > 0:
            discount_pct = int(round(((high - low) / high) * 100))

        return {
            "gift_name": name,
            "category": category,
            "estimated_price_label": f"₹{low:,}–₹{high:,}",
            "lowest_estimate": low,
            "highest_estimate": high,
            "average_estimate": average,
            "discount_percentage_estimate": discount_pct,
            "availability": "Verify on each platform — live stock not fetched",
            "shopping_links": platforms,
            "data_note": (
                "All amounts are AI/heuristic estimates, not live marketplace prices. "
                "Open a shopping link to see the real price."
            ),
            "is_estimate": True,
        }

    def _estimate_range(
        self,
        name: str,
        category: str,
        budget: int | None,
    ) -> tuple[int, int, int]:
        """Derive a stable estimate band from name/category/budget (not live prices)."""
        seed = int(hashlib.md5(f"{name}|{category}".encode()).hexdigest()[:8], 16)
        base_map = {
            "electronics": (1500, 12000),
            "technology": (1500, 12000),
            "jewellery": (2000, 25000),
            "fashion": (800, 8000),
            "books": (250, 1500),
            "handmade": (400, 3500),
            "personalized": (500, 4000),
            "luxury": (3000, 30000),
            "kids": (300, 2500),
            "food": (300, 2000),
            "general": (500, 5000),
        }
        cat_key = category.lower()
        low_base, high_base = base_map.get("general", (500, 5000))
        for key, band in base_map.items():
            if key in cat_key or key in name.lower():
                low_base, high_base = band
                break

        jitter = (seed % 20) / 100.0
        low = int(low_base * (0.9 + jitter))
        high = int(high_base * (0.95 + jitter / 2))
        if budget:
            # Keep estimates relevant to shopper budget without pretending accuracy.
            low = max(99, min(low, int(budget * 0.35)))
            high = max(low + 100, min(high, int(budget * 1.15)))
        average = int((low + high) / 2)
        return low, high, average
