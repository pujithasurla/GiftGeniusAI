"""AI Shopping Assistant chat agent with recommendation memory."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient


class ChatAgent(BaseAgent):
    """Intent-aware shopping assistant that remembers prior recommendations."""

    name = "chat"

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        message: str,
        *,
        memory: dict[str, Any] | None = None,
        profile: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Answer a shopper message and suggest a next route when useful.

        Returns:
            Dict with reply text, detected intent, and optional action path.
        """
        memory = memory or {}
        profile = profile or {}
        text = (message or "").strip()
        intent = self.detect_intent(text)
        reply = self._rule_reply(intent, text, memory, profile)

        if self.ollama and self.ollama.is_available():
            context = self._memory_blurb(memory, profile)
            polished = self.ask_ollama(
                (
                    f"Shopper said: {text}\nIntent: {intent}\nContext: {context}\n"
                    f"Draft reply to improve (keep under 80 words, no fake prices):\n{reply}"
                ),
                system=(
                    "You are GiftGenius AI shopping assistant. Be helpful and concise. "
                    "Never invent exact prices or store phone numbers. "
                    "If unsure, guide the user to the right tool."
                ),
                timeout=15,
                fallback=reply,
            )
            reply = polished.strip() or reply

        action = {
            "shops": "/gift/shops",
            "prices": "/gift/prices",
            "checklist": "/gift/checklist",
            "wrapping": "/gift/wrapping",
            "greeting": "/gift/greeting",
            "countdown": "/gift/countdown",
            "dashboard": "/gift/dashboard",
            "cheaper": "/gift/prices",
            "luxury": "/gift/prices",
            "handmade": "/gift/recommendations",
            "personalized": "/gift/recommendations",
            "under_budget": "/gift/recommendations",
            "general": None,
        }.get(intent)

        return {"reply": reply, "intent": intent, "action": action}

    def detect_intent(self, message: str) -> str:
        """Map free text to a shopping assistant intent."""
        m = message.lower()
        checks = [
            ("nearby", "shops"),
            ("gift shop", "shops"),
            ("where can i buy", "shops"),
            ("map", "shops"),
            ("flipkart", "prices"),
            ("amazon", "prices"),
            ("price", "prices"),
            ("compare", "prices"),
            ("cheaper", "cheaper"),
            ("luxury", "luxury"),
            ("handmade", "handmade"),
            ("personalized", "personalized"),
            ("under ₹", "under_budget"),
            ("under rs", "under_budget"),
            ("under 500", "under_budget"),
            ("checklist", "checklist"),
            ("greeting", "greeting"),
            ("wrapping", "wrapping"),
            ("wrap", "wrapping"),
            ("countdown", "countdown"),
            ("dashboard", "dashboard"),
        ]
        for needle, intent in checks:
            if needle in m:
                return intent
        return "general"

    def _rule_reply(
        self,
        intent: str,
        message: str,
        memory: dict[str, Any],
        profile: dict[str, Any],
    ) -> str:
        who = profile.get("recipient_name") or "your recipient"
        gifts = memory.get("gifts") or []
        gift_names = ", ".join(g.get("name", "") for g in gifts[:3] if g.get("name"))
        remembered = f" I still remember suggestions like {gift_names}." if gift_names else ""

        if intent == "shops":
            return (
                f"I can locate nearby gift shops for {who}. "
                "Open Shop Locator, share your city (or allow location), and I’ll list gift, flower, "
                f"book, and specialty stores with maps and directions.{remembered}"
            )
        if intent == "prices":
            return (
                "I can compare estimated online prices and send you to Amazon, Flipkart, Myntra, "
                "and more. Amounts are clearly labelled estimates — open each link for live pricing."
                f"{remembered}"
            )
        if intent == "cheaper":
            return (
                "For cheaper alternatives, open Price Comparison and sort toward lower estimate bands, "
                "or ask me for gifts under a specific budget like ₹500."
            )
        if intent == "luxury":
            return (
                "For luxury alternatives, filter Premium shops and higher estimate bands, "
                "or prefer Jewellery / Fashion / Technology gift types in your brief."
            )
        if intent == "handmade":
            return "Try handmade ceramic sets, DIY kits, or craft-store finds — open Recommendations or Handmade shop filters."
        if intent == "personalized":
            return "Personalized photo books and custom jewellery usually land well — open Recommendations filtered to Personalized."
        if intent == "under_budget":
            return "Set or revisit your interview budget, then open Recommendations / Prices to stay near that range."
        if intent == "checklist":
            return "I can generate a full shopping checklist (box, wrap, ribbon, card, extras) you can save, print, or download."
        if intent == "greeting":
            return "I can draft short, medium, and long greeting-card messages you can copy, print, or download."
        if intent == "wrapping":
            return "Pick a wrapping theme (Birthday, Luxury, Minimal…) and I’ll suggest paper, ribbon, bow, DIY steps, and cost."
        if intent == "countdown":
            return "Add the occasion date to see days/hours remaining plus timely buy/wrap reminders."
        if intent == "dashboard":
            return "Your Premium Dashboard gathers match score, shops map, prices, checklist, wrapping, and greetings in one place."
        return (
            f"I can help with shops, online price estimates, checklists, wrapping, and greetings for {who}. "
            f"Try asking: “Show nearby gift shops” or “Compare Amazon and Flipkart prices.”{remembered}"
        )

    def _memory_blurb(self, memory: dict[str, Any], profile: dict[str, Any]) -> str:
        gifts = memory.get("gifts") or []
        names = [g.get("name") for g in gifts[:5] if g.get("name")]
        return (
            f"recipient={profile.get('recipient_name')}; "
            f"occasion={profile.get('occasion')}; "
            f"budget={profile.get('budget')}; "
            f"gifts={names}"
        )
