"""Smart Gift Shop Locator Agent — finds nearby gift-related stores."""

from __future__ import annotations

from typing import Any

from agents.base_agent import BaseAgent
from utils.geo import geocode_place, query_nearby_shops
from utils.ollama_client import OllamaClient


class ShopLocatorAgent(BaseAgent):
    """Locate nearby gift, flower, toy, book, and specialty shops for a location."""

    name = "shop_locator"

    CATEGORIES = [
        "Gift Shops",
        "Flower Shops",
        "Toy Stores",
        "Book Stores",
        "Electronics Stores",
        "Jewellery Stores",
        "Handmade Gift Stores",
        "Fashion Stores",
        "Cake Shops",
        "Chocolate Shops",
        "Customized Gift Shops",
    ]

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def run(
        self,
        *,
        current_location: str | None = None,
        city: str | None = None,
        state: str | None = None,
        country: str | None = None,
        sort_by: str = "nearest",
        limit: int = 10,
        radius_m: int = 6000,
    ) -> dict[str, Any]:
        """
        Resolve a location and return top nearby shops.

        When live OSM data is sparse, returns city-centred guidance with an
        explicit data_note — never invents fake store listings with fake phones.
        """
        location = geocode_place(
            query=current_location,
            city=city,
            state=state,
            country=country,
        )
        if location is None:
            return {
                "ok": False,
                "error": "Could not resolve that location. Try a city name or a fuller address.",
                "shops": [],
                "location": None,
                "sort_by": sort_by,
            }

        shops = query_nearby_shops(
            location["lat"],
            location["lon"],
            radius_m=radius_m,
            categories=self.CATEGORIES,
        )
        data_note = "Listings sourced from OpenStreetMap. Ratings shown only when publicly available."
        if not shops:
            data_note = (
                "No OpenStreetMap shop points found near this location. "
                "Try another city, widen your area, or use the online price tools meanwhile. "
                "We do not invent store names, phones, or ratings."
            )

        shops = self.sort_shops(shops, sort_by)[:limit]
        self.logger.info(
            "Located %s shops near %s (sort=%s)",
            len(shops),
            location.get("display_name"),
            sort_by,
        )
        return {
            "ok": True,
            "error": None,
            "location": location,
            "shops": shops,
            "sort_by": sort_by,
            "categories": self.CATEGORIES,
            "data_note": data_note,
            "count": len(shops),
        }

    def sort_shops(self, shops: list[dict[str, Any]], sort_by: str) -> list[dict[str, Any]]:
        key = (sort_by or "nearest").lower().replace(" ", "_")
        if key in {"highest_rated", "rating"}:
            # OSM rarely has ratings — fall back to nearest among rated, else nearest.
            return sorted(
                shops,
                key=lambda s: (
                    0 if s.get("rating") is not None else 1,
                    -(s.get("rating") or 0),
                    s.get("distance_km") or 999,
                ),
            )
        if key in {"budget_friendly", "budget"}:
            order = {"budget": 0, "mid": 1, "premium": 2}
            return sorted(
                shops,
                key=lambda s: (order.get(s.get("tier", "mid"), 1), s.get("distance_km") or 999),
            )
        if key == "premium":
            order = {"premium": 0, "mid": 1, "budget": 2}
            return sorted(
                shops,
                key=lambda s: (order.get(s.get("tier", "mid"), 1), s.get("distance_km") or 999),
            )
        return sorted(shops, key=lambda s: s.get("distance_km") or 999)
