"""Interview Agent — guides users through a one-question-at-a-time gift interview."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from agents.base_agent import BaseAgent
from utils.ollama_client import OllamaClient

QuestionType = Literal["text", "number", "select", "multiselect"]


@dataclass(frozen=True)
class InterviewQuestion:
    """A single interview prompt shown to the shopper."""

    key: str
    label: str
    prompt: str
    hint: str
    field_type: QuestionType
    required: bool = True
    options: tuple[str, ...] = ()
    placeholder: str = ""
    min_value: int | None = None
    max_value: int | None = None
    allow_custom: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Serialize for templates and JSON responses."""
        data = asdict(self)
        data["options"] = list(self.options)
        return data


@dataclass
class InterviewResult:
    """Structured output produced when an interview completes."""

    answers: dict[str, Any]
    profile: dict[str, Any]
    summary: str
    acknowledgements: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for session storage and templates."""
        return {
            "answers": self.answers,
            "profile": self.profile,
            "summary": self.summary,
            "acknowledgements": self.acknowledgements,
        }


class InterviewAgent(BaseAgent):
    """
    Conducts a structured gift interview one question at a time.

    Uses Ollama for warm acknowledgements and a closing narrative when available,
    with curated offline fallbacks so the flow always works.
    """

    name = "interview"

    SYSTEM_PROMPT = (
        "You are GiftGenius AI, a warm, concise shopping interview assistant. "
        "Speak in 1–2 short sentences. Never invent recipient details the user did not provide. "
        "Avoid emojis unless the user used them."
    )

    QUESTIONS: tuple[InterviewQuestion, ...] = (
        InterviewQuestion(
            key="recipient_name",
            label="Recipient Name",
            prompt="Who are you shopping for?",
            hint="Enter their first name or how you usually refer to them.",
            field_type="text",
            placeholder="e.g. Priya",
        ),
        InterviewQuestion(
            key="recipient_age",
            label="Recipient Age",
            prompt="How old is the recipient?",
            hint="Approximate age is fine if you are unsure.",
            field_type="number",
            placeholder="e.g. 28",
            min_value=1,
            max_value=120,
        ),
        InterviewQuestion(
            key="gender",
            label="Gender",
            prompt="How should we think about their gender for gift styling?",
            hint="Choose the option that best matches how you want gifts framed.",
            field_type="select",
            options=("Woman", "Man", "Non-binary", "Prefer not to say", "Other"),
            allow_custom=True,
        ),
        InterviewQuestion(
            key="relationship",
            label="Relationship",
            prompt="What is your relationship to them?",
            hint="This shapes tone, formality, and surprise level.",
            field_type="select",
            options=(
                "Friend",
                "Mother",
                "Father",
                "Brother",
                "Sister",
                "Husband",
                "Wife",
                "Partner",
                "Teacher",
                "Boss",
                "Colleague",
                "Child",
                "Other",
            ),
            allow_custom=True,
        ),
        InterviewQuestion(
            key="occasion",
            label="Occasion",
            prompt="What is the occasion?",
            hint="Pick the celebration that this gift is for.",
            field_type="select",
            options=(
                "Birthday",
                "Wedding",
                "Anniversary",
                "Festival",
                "Graduation",
                "Baby Shower",
                "Housewarming",
                "Christmas",
                "Valentine's Day",
                "Just Because",
                "Other",
            ),
            allow_custom=True,
        ),
        InterviewQuestion(
            key="budget",
            label="Budget",
            prompt="What is your total budget for this gift?",
            hint="Enter an amount in ₹ (Indian Rupees).",
            field_type="number",
            placeholder="e.g. 2500",
            min_value=100,
            max_value=1_000_000,
        ),
        InterviewQuestion(
            key="interests",
            label="Interests",
            prompt="What are their main interests?",
            hint="Select all that apply, or add your own.",
            field_type="multiselect",
            required=False,
            options=(
                "Technology",
                "Fashion",
                "Cooking",
                "Travel",
                "Fitness",
                "Art",
                "Music",
                "Gaming",
                "Photography",
                "Gardening",
                "Pets",
                "Wellness",
            ),
            allow_custom=True,
        ),
        InterviewQuestion(
            key="hobbies",
            label="Hobbies",
            prompt="What hobbies do they enjoy in their free time?",
            hint="Optional — helps us find memorable gifts.",
            field_type="text",
            required=False,
            placeholder="e.g. weekend baking, weekend treks",
        ),
        InterviewQuestion(
            key="favorite_color",
            label="Favorite Color",
            prompt="Do they have a favourite colour?",
            hint="Optional — useful for fashion, decor, and packaging.",
            field_type="text",
            required=False,
            placeholder="e.g. deep green",
        ),
        InterviewQuestion(
            key="favorite_brand",
            label="Favorite Brand",
            prompt="Are there brands they love?",
            hint="Optional — leave blank if you are not sure.",
            field_type="text",
            required=False,
            placeholder="e.g. Apple, Nike, Faber-Castell",
        ),
        InterviewQuestion(
            key="favorite_movies",
            label="Favorite Movies",
            prompt="Any favourite movies, shows, or genres?",
            hint="Optional.",
            field_type="text",
            required=False,
            placeholder="e.g. Studio Ghibli, thrillers",
        ),
        InterviewQuestion(
            key="favorite_books",
            label="Favorite Books",
            prompt="What kinds of books or authors do they enjoy?",
            hint="Optional.",
            field_type="text",
            required=False,
            placeholder="e.g. mysteries, biographies",
        ),
        InterviewQuestion(
            key="favorite_food",
            label="Favorite Food",
            prompt="What food or flavours do they love?",
            hint="Optional — great for gourmet and experience gifts.",
            field_type="text",
            required=False,
            placeholder="e.g. dark chocolate, South Indian breakfast",
        ),
        InterviewQuestion(
            key="occupation",
            label="Occupation",
            prompt="What do they do for work or study?",
            hint="Optional, but very useful for practical gifts.",
            field_type="text",
            required=False,
            placeholder="e.g. software engineer, teacher",
        ),
        InterviewQuestion(
            key="location",
            label="Location",
            prompt="Where do they live?",
            hint="City or country helps with climate and delivery realism.",
            field_type="text",
            required=False,
            placeholder="e.g. Bengaluru, India",
        ),
        InterviewQuestion(
            key="gift_type",
            label="Gift Type",
            prompt="What style of gift are you aiming for?",
            hint="Select one or more directions.",
            field_type="multiselect",
            options=(
                "Practical",
                "Luxury",
                "Personalized",
                "Handmade",
                "Technology",
                "Fashion",
                "Books",
                "Accessories",
            ),
        ),
        InterviewQuestion(
            key="surprise_level",
            label="Surprise Level",
            prompt="How surprising should this gift feel?",
            hint="Simple is safe and useful. Premium leans bold and memorable.",
            field_type="select",
            options=("Simple", "Creative", "Premium"),
        ),
    )

    def __init__(self, ollama: OllamaClient | None = None) -> None:
        super().__init__(ollama=ollama)

    def question_count(self) -> int:
        """Return the number of interview questions."""
        return len(self.QUESTIONS)

    def get_question(self, index: int) -> InterviewQuestion | None:
        """Return the question at index, or None if out of range."""
        if 0 <= index < len(self.QUESTIONS):
            return self.QUESTIONS[index]
        return None

    def progress_percent(self, index: int) -> int:
        """Return completion percentage for the current question index."""
        total = self.question_count()
        if total == 0:
            return 100
        clamped = max(0, min(index, total))
        return int((clamped / total) * 100)

    def validate_answer(
        self,
        question: InterviewQuestion,
        raw_answer: Any,
    ) -> tuple[bool, str, Any]:
        """
        Validate and normalise a user answer.

        Returns:
            Tuple of (is_valid, error_message, normalised_value).
        """
        if question.field_type == "multiselect":
            values = self._as_list(raw_answer)
            values = [v.strip() for v in values if str(v).strip()]
            if question.required and not values:
                return False, "Please select at least one option.", None
            return True, "", values

        if question.field_type == "select":
            value = str(raw_answer or "").strip()
            if not value and question.required:
                return False, "Please choose an option.", None
            if (
                value
                and question.options
                and value not in question.options
                and not question.allow_custom
            ):
                return False, "Please choose one of the listed options.", None
            return True, "", value

        if question.field_type == "number":
            text = str(raw_answer or "").strip().replace(",", "").replace("₹", "")
            if not text:
                if question.required:
                    return False, "Please enter a number.", None
                return True, "", None
            try:
                number = int(float(text))
            except ValueError:
                return False, "Please enter a valid number.", None
            if question.min_value is not None and number < question.min_value:
                return False, f"Please enter at least {question.min_value}.", None
            if question.max_value is not None and number > question.max_value:
                return False, f"Please enter at most {question.max_value}.", None
            return True, "", number

        value = str(raw_answer or "").strip()
        if question.required and not value:
            return False, "This answer is required.", None
        if len(value) > 400:
            return False, "Please keep your answer under 400 characters.", None
        return True, "", value or None

    def craft_opening(self) -> str:
        """Return a short opening message for the interview."""
        fallback = (
            "I will ask a few focused questions — one at a time — so we can learn "
            "who you are shopping for and what would delight them."
        )
        return self.ask_ollama(
            "Write a brief welcome for a gift interview. Mention you will ask questions one by one.",
            system=self.SYSTEM_PROMPT,
            temperature=0.5,
            timeout=12,
            fallback=fallback,
        )

    def craft_acknowledgement(
        self,
        question: InterviewQuestion,
        answer: Any,
        answers_so_far: dict[str, Any],
    ) -> str:
        """
        Return a short acknowledgement after an answer is accepted.

        Uses curated, personalised templates so each step stays snappy.
        Ollama is reserved for opening + closing summary.
        """
        display = self.format_answer(answer)
        fallback_map = {
            "recipient_name": f"Great — shopping for {display}. Let's learn a little more.",
            "recipient_age": f"Got it — age {display}. That helps narrow styles and interests.",
            "gender": f"Noted — I will keep styling cues aligned with {display}.",
            "relationship": f"Understood — you are shopping for your {display.lower()}.",
            "occasion": f"Perfect — a {display} gift deserves thoughtful consideration.",
            "budget": f"Budget noted: ₹{display}. I will keep recommendations within range.",
            "interests": f"Interests captured: {display}. Strong signal for gift direction.",
            "hobbies": f"Hobbies noted: {display}.",
            "favorite_color": f"Favourite colour saved: {display}.",
            "favorite_brand": f"Brand preference noted: {display}.",
            "favorite_movies": f"Media tastes noted: {display}.",
            "favorite_books": f"Reading tastes noted: {display}.",
            "favorite_food": f"Food favourites noted: {display}.",
            "occupation": f"Occupation noted: {display}. Helpful for practical picks.",
            "location": f"Location saved: {display}.",
            "gift_type": f"Gift direction set to {display}.",
            "surprise_level": f"{display} surprise level noted — I will keep that in mind.",
        }
        ack = fallback_map.get(
            question.key,
            f"Thanks — I have noted their {question.label.lower()}.",
        )
        if answer is None or answer == [] or answer == "":
            return f"No problem — we can skip {question.label.lower()} for now."
        return ack

    def build_profile(self, answers: dict[str, Any]) -> dict[str, Any]:
        """Build a structured recipient profile from interview answers."""
        interests = answers.get("interests") or []
        gift_types = answers.get("gift_type") or []
        budget = answers.get("budget")

        budget_band = "unspecified"
        if isinstance(budget, int):
            if budget < 1000:
                budget_band = "affordable"
            elif budget < 5000:
                budget_band = "mid-range"
            else:
                budget_band = "premium"

        return {
            "recipient_name": answers.get("recipient_name"),
            "age": answers.get("recipient_age"),
            "gender": answers.get("gender"),
            "relationship": answers.get("relationship"),
            "occasion": answers.get("occasion"),
            "budget": budget,
            "budget_band": budget_band,
            "interests": interests,
            "hobbies": answers.get("hobbies"),
            "favorites": {
                "color": answers.get("favorite_color"),
                "brand": answers.get("favorite_brand"),
                "movies": answers.get("favorite_movies"),
                "books": answers.get("favorite_books"),
                "food": answers.get("favorite_food"),
            },
            "occupation": answers.get("occupation"),
            "location": answers.get("location"),
            "gift_types": gift_types,
            "surprise_level": answers.get("surprise_level"),
        }

    def summarize_interview(self, answers: dict[str, Any]) -> str:
        """Generate a short narrative summary of the completed interview."""
        profile = self.build_profile(answers)
        lines = [
            f"Recipient: {profile.get('recipient_name')}",
            f"Age: {profile.get('age')}",
            f"Relationship: {profile.get('relationship')}",
            f"Occasion: {profile.get('occasion')}",
            f"Budget: ₹{profile.get('budget')}",
            f"Interests: {', '.join(profile.get('interests') or []) or 'n/a'}",
            f"Gift types: {', '.join(profile.get('gift_types') or []) or 'n/a'}",
            f"Surprise level: {profile.get('surprise_level')}",
            f"Occupation: {profile.get('occupation') or 'n/a'}",
            f"Location: {profile.get('location') or 'n/a'}",
        ]
        fallback = (
            f"You are shopping for {profile.get('recipient_name')} "
            f"({profile.get('relationship')}) for {profile.get('occasion')} "
            f"with a budget of ₹{profile.get('budget')}. "
            f"Preferred gift direction: {', '.join(profile.get('gift_types') or ['open'])}. "
            f"Surprise level: {profile.get('surprise_level')}."
        )
        prompt = (
            "Write a polished 3–4 sentence gift brief from this interview profile. "
            "Sound like a smart shopping assistant summarizing for the next analysis step.\n"
            + "\n".join(lines)
        )
        return self.ask_ollama(
            prompt,
            system=self.SYSTEM_PROMPT,
            temperature=0.45,
            timeout=45,
            fallback=fallback,
        )

    def run(self, answers: dict[str, Any]) -> InterviewResult:
        """Complete the interview by building profile + summary from answers."""
        profile = self.build_profile(answers)
        summary = self.summarize_interview(answers)
        self.logger.info(
            "Interview completed for recipient=%s occasion=%s budget=%s",
            profile.get("recipient_name"),
            profile.get("occasion"),
            profile.get("budget"),
        )
        return InterviewResult(answers=answers, profile=profile, summary=summary)

    @staticmethod
    def format_answer(answer: Any) -> str:
        """Pretty-print an answer for acknowledgements and summaries."""
        if answer is None:
            return "skipped"
        if isinstance(answer, list):
            return ", ".join(str(item) for item in answer) if answer else "skipped"
        return str(answer)

    @staticmethod
    def _as_list(raw_answer: Any) -> list[str]:
        if raw_answer is None:
            return []
        if isinstance(raw_answer, list):
            return [str(item) for item in raw_answer]
        if isinstance(raw_answer, str):
            # Support comma-separated custom entries from a single field.
            if "," in raw_answer and "\n" not in raw_answer:
                return [part.strip() for part in raw_answer.split(",") if part.strip()]
            return [raw_answer]
        return [str(raw_answer)]
