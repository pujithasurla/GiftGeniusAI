/**
 * GiftGenius AI — UI interactions
 * Theme persistence, loader, and navbar polish.
 */
(function () {
  "use strict";

  const THEME_KEY = "giftgenius-theme";
  const root = document.documentElement;
  const themeToggle = document.getElementById("themeToggle");
  const themeIcon = document.getElementById("themeIcon");
  const pageLoader = document.getElementById("pageLoader");

  function preferredTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === "light" || saved === "dark") {
      return saved;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  }

  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    if (themeIcon) {
      themeIcon.className =
        theme === "dark" ? "bi bi-sun" : "bi bi-moon-stars";
    }
  }

  function toggleTheme() {
    const next =
      root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  }

  applyTheme(preferredTheme());

  if (themeToggle) {
    themeToggle.addEventListener("click", toggleTheme);
  }

  document.querySelectorAll('a[href^="/"]').forEach(function (link) {
    link.addEventListener("click", function (event) {
      if (
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey ||
        link.target === "_blank"
      ) {
        return;
      }
      if (pageLoader) {
        pageLoader.hidden = false;
      }
    });
  });

  window.addEventListener("pageshow", function () {
    if (pageLoader) {
      pageLoader.hidden = true;
    }
  });
})();
