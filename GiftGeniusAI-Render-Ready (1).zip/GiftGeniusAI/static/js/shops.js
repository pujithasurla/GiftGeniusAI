/**
 * Leaflet map renderer shared by Shop Locator and Dashboard.
 */
(function () {
  "use strict";

  function initMap(el) {
    if (!el || typeof L === "undefined") {
      return;
    }
    let shops = [];
    let origin = null;
    try {
      shops = JSON.parse(el.getAttribute("data-shops") || "[]") || [];
      origin = JSON.parse(el.getAttribute("data-origin") || "null");
    } catch (err) {
      shops = [];
    }

    const center = origin
      ? [origin.lat, origin.lon]
      : shops[0]
        ? [shops[0].lat, shops[0].lon]
        : [20.5937, 78.9629];

    const map = L.map(el).setView(center, shops.length ? 13 : 5);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap",
    }).addTo(map);

    if (origin && origin.lat && origin.lon) {
      L.circleMarker([origin.lat, origin.lon], {
        radius: 8,
        color: "#0f5c4c",
        fillColor: "#0f5c4c",
        fillOpacity: 0.9,
      })
        .addTo(map)
        .bindPopup("Your search centre");
    }

    const bounds = [];
    shops.forEach(function (shop) {
      if (shop.lat == null || shop.lon == null) {
        return;
      }
      const marker = L.marker([shop.lat, shop.lon]).addTo(map);
      marker.bindPopup(
        "<strong>" +
          shop.name +
          "</strong><br>" +
          (shop.category || "") +
          "<br>" +
          (shop.distance_km != null ? shop.distance_km + " km" : "")
      );
      bounds.push([shop.lat, shop.lon]);
    });
    if (bounds.length > 1) {
      map.fitBounds(bounds, { padding: [28, 28] });
    }
  }

  document.querySelectorAll("#shopsMap").forEach(initMap);
})();
