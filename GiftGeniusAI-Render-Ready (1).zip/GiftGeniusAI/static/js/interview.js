/**
 * Interview UI helpers — custom-answer chips and keyboard affordances.
 */
(function () {
  "use strict";

  const form = document.getElementById("interviewForm");
  if (!form) {
    return;
  }

  const customRadio = document.getElementById("customRadio");
  const customAnswer = document.getElementById("customAnswer");

  if (customRadio && customAnswer) {
    const syncCustom = function () {
      if (customRadio.checked) {
        customAnswer.focus();
      }
    };

    customRadio.addEventListener("change", syncCustom);
    customAnswer.addEventListener("focus", function () {
      customRadio.checked = true;
    });

    form.addEventListener("submit", function (event) {
      const submitter = event.submitter;
      const action = submitter && submitter.name === "action" ? submitter.value : "next";
      if (action !== "next") {
        return;
      }
      if (customRadio.checked && !customAnswer.value.trim()) {
        event.preventDefault();
        customAnswer.reportValidity();
        customAnswer.setCustomValidity("Please type your custom answer.");
        customAnswer.reportValidity();
        customAnswer.setCustomValidity("");
      }
    });
  }

  form.querySelectorAll(".option-chip input").forEach(function (input) {
    input.addEventListener("change", function () {
      const chip = input.closest(".option-chip");
      if (!chip) {
        return;
      }
      if (input.type === "radio") {
        form.querySelectorAll(".option-chip").forEach(function (el) {
          el.classList.toggle("is-selected", el.contains(input) && input.checked);
        });
      } else {
        chip.classList.toggle("is-selected", input.checked);
      }
    });

    if (input.checked) {
      input.dispatchEvent(new Event("change"));
    }
  });
})();
