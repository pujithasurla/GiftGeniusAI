/**
 * Dashboard charts, map, and countdown chip.
 */
(function () {
  "use strict";

  const budget = window.GG_BUDGET_CHART || {};
  const canvas = document.getElementById("budgetChart");
  if (canvas && typeof Chart !== "undefined") {
    const style = getComputedStyle(document.documentElement);
    const pine = style.getPropertyValue("--gg-pine").trim() || "#0f5c4c";
    const berry = style.getPropertyValue("--gg-berry").trim() || "#c45c4a";
    const sand = style.getPropertyValue("--gg-sand").trim() || "#d9e2da";
    new Chart(canvas, {
      type: "doughnut",
      data: {
        labels: ["Affordable", "Mid-range", "Premium"],
        datasets: [
          {
            data: [budget.affordable || 0, budget.mid || 0, budget.premium || 0],
            backgroundColor: [pine, berry, sand],
            borderWidth: 0,
          },
        ],
      },
      options: {
        plugins: {
          legend: { position: "bottom" },
        },
        cutout: "62%",
      },
    });
  }

  // Map bootstrapped by shops.js if #shopsMap exists.

  const dateStr = window.GG_COUNTDOWN_DATE;
  const daysEl = document.getElementById("dashCountdownDays");
  if (dateStr && daysEl) {
    const target = new Date(dateStr + "T23:59:59");
    const diff = target.getTime() - Date.now();
    if (diff <= 0) {
      daysEl.textContent = "Today!";
    } else {
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      daysEl.textContent = days + "d " + hours + "h left";
    }
  }
})();
