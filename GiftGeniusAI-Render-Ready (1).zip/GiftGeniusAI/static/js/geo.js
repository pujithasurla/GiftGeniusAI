/**
 * Geolocation helper for Shop Locator form.
 */
(function () {
  "use strict";

  const btn = document.getElementById("useGeoBtn");
  const status = document.getElementById("geoStatus");
  const field = document.getElementById("current_location");
  if (!btn || !field) {
    return;
  }

  btn.addEventListener("click", function () {
    if (!navigator.geolocation) {
      if (status) {
        status.textContent = "Location services unavailable — enter a city manually.";
      }
      return;
    }
    if (status) {
      status.textContent = "Getting your location…";
    }
    navigator.geolocation.getCurrentPosition(
      function (pos) {
        const lat = pos.coords.latitude.toFixed(5);
        const lon = pos.coords.longitude.toFixed(5);
        field.value = lat + ", " + lon;
        if (status) {
          status.textContent = "Location captured. Click Find Top 10 Shops.";
        }
      },
      function () {
        if (status) {
          status.textContent =
            "Could not access location. Please enter city / state / country manually.";
        }
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  });
})();
