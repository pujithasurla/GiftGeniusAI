/**
 * Occasion countdown panel with tips and celebration state.
 */
(function () {
  "use strict";

  const panel = document.getElementById("countdownPanel");
  if (!panel) {
    return;
  }

  const dateStr = panel.getAttribute("data-date");
  const label = panel.getAttribute("data-label") || "Occasion";
  const daysEl = document.getElementById("cdDays");
  const hoursEl = document.getElementById("cdHours");
  const bar = document.getElementById("cdBar");
  const tips = document.getElementById("cdTips");
  const celebrate = document.getElementById("celebrate");

  function suggestions(days) {
    if (days <= 0) {
      return ["Gift day is here — celebrate!", "Add the finishing bow", "Don't forget the greeting card"];
    }
    if (days <= 2) {
      return ["Order online today", "Start gift wrapping", "Don't forget greeting card"];
    }
    if (days <= 7) {
      return ["Buy this week", "Compare online estimates", "Prepare wrapping supplies"];
    }
    return ["Shortlist 2–3 gifts", "Check nearby shops", "Set a budget-friendly backup"];
  }

  function tick() {
    const target = new Date(dateStr + "T23:59:59");
    const now = new Date();
    let diff = target.getTime() - now.getTime();
    if (diff < 0) {
      diff = 0;
    }
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    if (daysEl) {
      daysEl.textContent = String(days);
    }
    if (hoursEl) {
      hoursEl.textContent = String(hours);
    }

    // Progress against a 30-day planning window.
    const windowMs = 30 * 24 * 60 * 60 * 1000;
    const elapsed = Math.min(windowMs, Math.max(0, windowMs - diff));
    const pct = Math.round((elapsed / windowMs) * 100);
    if (bar) {
      bar.style.width = pct + "%";
    }

    if (tips) {
      tips.innerHTML = suggestions(days)
        .map(function (t) {
          return "<li>" + t + "</li>";
        })
        .join("");
    }

    if (celebrate) {
      const due = diff === 0;
      celebrate.hidden = !due;
      panel.classList.toggle("is-celebrate", due);
    }
  }

  tick();
  setInterval(tick, 60000);
})();
