"""Route package for GiftGenius AI blueprints."""

from routes.chat import chat_bp
from routes.gift import gift_bp
from routes.main import main_bp
from routes.report import report_bp
from routes.shopping import shopping_bp

__all__ = ["main_bp", "gift_bp", "chat_bp", "report_bp", "shopping_bp"]
