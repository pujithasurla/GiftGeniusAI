"""Gift recommendation report routes."""

from __future__ import annotations

from flask import Blueprint, render_template

report_bp = Blueprint("report", __name__, url_prefix="/report")


@report_bp.route("/")
def report_home() -> str:
    """Report generation entry point (PDF/HTML in a later phase)."""
    feature = {
        "title": "Gift Recommendation Report",
        "subtitle": "Generate printable HTML and PDF reports with summaries, comparisons, and shopping tips.",
        "phase": "Phase 5",
    }
    return render_template("report.html", feature=feature)
