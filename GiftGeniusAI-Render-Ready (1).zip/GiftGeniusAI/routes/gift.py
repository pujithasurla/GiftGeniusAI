"""Gift discovery, interview, dashboard, and comparison routes."""

from __future__ import annotations

from typing import Any

from flask import (
    Blueprint,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from agents.interview_agent import InterviewAgent, InterviewQuestion
from utils.interview_session import (
    append_search_history,
    build_history_entry,
    clear_interview_state,
    create_agent_from_app,
    get_interview_state,
    get_search_history,
    new_interview_state,
    save_interview_state,
)
from utils.logger import get_logger

gift_bp = Blueprint("gift", __name__, url_prefix="/gift")
logger = get_logger("routes.gift")

FEATURE_SHELLS: dict[str, dict[str, str]] = {
    "categories": {
        "title": "Explore Gift Categories",
        "subtitle": "Browse electronics, fashion, books, home, gaming, travel, and more.",
        "phase": "Phase 3",
    },
    "occasions": {
        "title": "Occasion Explorer",
        "subtitle": "Generate occasion-specific gift ideas for birthdays, weddings, festivals, and more.",
        "phase": "Phase 3",
    },
    "dashboard": {
        "title": "Recommendation Dashboard",
        "subtitle": "Track recipient insights, budget distribution, and top-ranked gift recommendations.",
        "phase": "Phase 4",
    },
    "recommendations": {
        "title": "Gift Recommendations",
        "subtitle": "Top 10 personalised gifts with scores, pros, cons, and AI explanations.",
        "phase": "Phase 4",
    },
    "comparison": {
        "title": "Gift Comparison",
        "subtitle": "Side-by-side comparison of features, price, suitability, and overall rating.",
        "phase": "Phase 5",
    },
}


def _agent() -> InterviewAgent:
    return create_agent_from_app(current_app.extensions)


def _extract_answer(question: InterviewQuestion) -> Any:
    """Pull the submitted answer from the current request form."""
    if question.field_type == "multiselect":
        values = request.form.getlist("answer")
        custom = (request.form.get("custom_answer") or "").strip()
        if custom:
            values.extend(
                [part.strip() for part in custom.split(",") if part.strip()]
            )
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for item in values:
            key = item.strip()
            if key and key.lower() not in seen:
                seen.add(key.lower())
                unique.append(key)
        return unique

    answer = (request.form.get("answer") or "").strip()
    custom = (request.form.get("custom_answer") or "").strip()
    if answer == "__custom__":
        return custom
    return answer


@gift_bp.route("/interview", methods=["GET"])
def interview() -> Any:
    """Interview landing — start, resume, or view intro."""
    state = get_interview_state()
    agent = _agent()
    ollama_online = False
    ollama = current_app.extensions.get("ollama")
    if ollama is not None:
        ollama_online = ollama.is_available()

    if state and state.get("complete"):
        return redirect(url_for("gift.interview_summary"))

    if state and not state.get("complete"):
        return redirect(url_for("gift.interview_ask"))

    return render_template(
        "interview.html",
        mode="intro",
        question_count=agent.question_count(),
        ollama_online=ollama_online,
        ollama_model=current_app.config.get("OLLAMA_MODEL", "llama3"),
        history=get_search_history()[:5],
    )


@gift_bp.route("/interview/start", methods=["POST"])
def interview_start() -> Any:
    """Begin a new interview session."""
    clear_interview_state()
    agent = _agent()
    opening = agent.craft_opening()
    state = new_interview_state(opening)
    save_interview_state(state)
    logger.info("Interview started")
    return redirect(url_for("gift.interview_ask"))


@gift_bp.route("/interview/ask", methods=["GET"])
def interview_ask() -> Any:
    """Show the current interview question."""
    state = get_interview_state()
    if not state:
        flash("Start an interview to begin finding the perfect gift.", "info")
        return redirect(url_for("gift.interview"))

    if state.get("complete"):
        return redirect(url_for("gift.interview_summary"))

    agent = _agent()
    index = int(state.get("current_index", 0))
    question = agent.get_question(index)

    if question is None:
        return redirect(url_for("gift.interview_complete"))

    existing = state.get("answers", {}).get(question.key)
    last_ack = None
    acks = state.get("acknowledgements") or []
    if acks:
        last_ack = acks[-1]

    return render_template(
        "interview.html",
        mode="question",
        question=question,
        question_index=index,
        question_number=index + 1,
        question_count=agent.question_count(),
        progress=agent.progress_percent(index),
        existing_answer=existing,
        last_ack=last_ack,
        opening=state.get("opening") if index == 0 else None,
        can_go_back=index > 0,
    )


@gift_bp.route("/interview/answer", methods=["POST"])
def interview_answer() -> Any:
    """Accept the answer for the current question and advance."""
    state = get_interview_state()
    if not state or state.get("complete"):
        return redirect(url_for("gift.interview"))

    agent = _agent()
    index = int(state.get("current_index", 0))
    question = agent.get_question(index)
    if question is None:
        return redirect(url_for("gift.interview_complete"))

    raw = _extract_answer(question)
    action = (request.form.get("action") or "next").lower()

    if action == "skip":
        if question.required:
            flash("This question is required and cannot be skipped.", "warning")
            return redirect(url_for("gift.interview_ask"))
        normalised: Any = [] if question.field_type == "multiselect" else None
        ok, error = True, ""
    else:
        ok, error, normalised = agent.validate_answer(question, raw)

    if not ok:
        flash(error or "Please check your answer.", "warning")
        return redirect(url_for("gift.interview_ask"))

    answers = dict(state.get("answers") or {})
    answers[question.key] = normalised
    state["answers"] = answers

    ack = agent.craft_acknowledgement(question, normalised, answers)
    acks = list(state.get("acknowledgements") or [])
    acks.append(ack)
    state["acknowledgements"] = acks
    state["current_index"] = index + 1
    save_interview_state(state)

    if state["current_index"] >= agent.question_count():
        return redirect(url_for("gift.interview_complete"))

    return redirect(url_for("gift.interview_ask"))


@gift_bp.route("/interview/back", methods=["POST"])
def interview_back() -> Any:
    """Move one question backward without discarding earlier answers."""
    state = get_interview_state()
    if not state or state.get("complete"):
        return redirect(url_for("gift.interview"))

    index = int(state.get("current_index", 0))
    if index > 0:
        state["current_index"] = index - 1
        save_interview_state(state)
    return redirect(url_for("gift.interview_ask"))


@gift_bp.route("/interview/complete", methods=["GET", "POST"])
def interview_complete() -> Any:
    """Finalize the interview with profile + AI summary."""
    state = get_interview_state()
    if not state:
        return redirect(url_for("gift.interview"))

    if state.get("complete") and state.get("summary"):
        return redirect(url_for("gift.interview_summary"))

    agent = _agent()
    answers = dict(state.get("answers") or {})
    result = agent.run(answers)
    payload = result.to_dict()

    state["complete"] = True
    state["profile"] = payload["profile"]
    state["summary"] = payload["summary"]
    state["completed_at"] = state.get("updated_at")
    save_interview_state(state)
    append_search_history(build_history_entry(payload))
    logger.info("Interview completed and saved to search history")
    return redirect(url_for("gift.interview_summary"))


@gift_bp.route("/interview/summary", methods=["GET"])
def interview_summary() -> Any:
    """Show the completed interview brief."""
    state = get_interview_state()
    if not state or not state.get("complete"):
        flash("Finish the interview to view your gift brief.", "info")
        return redirect(url_for("gift.interview"))

    agent = _agent()
    answered_rows = []
    for question in agent.QUESTIONS:
        value = (state.get("answers") or {}).get(question.key)
        answered_rows.append(
            {
                "label": question.label,
                "value": agent.format_answer(value),
            }
        )

    return render_template(
        "interview.html",
        mode="summary",
        profile=state.get("profile") or {},
        summary=state.get("summary") or "",
        answered_rows=answered_rows,
        acknowledgements=state.get("acknowledgements") or [],
    )


@gift_bp.route("/interview/restart", methods=["POST"])
def interview_restart() -> Any:
    """Clear session and return to interview intro."""
    clear_interview_state()
    flash("Interview reset. Start fresh whenever you are ready.", "success")
    return redirect(url_for("gift.interview"))


@gift_bp.route("/categories")
def categories() -> str:
    """Category explorer entry point."""
    return render_template("feature_shell.html", feature=FEATURE_SHELLS["categories"])


@gift_bp.route("/occasions")
def occasions() -> str:
    """Occasion explorer entry point."""
    return render_template("feature_shell.html", feature=FEATURE_SHELLS["occasions"])


@gift_bp.route("/dashboard")
def dashboard() -> Any:
    """Premium shopping dashboard aggregating all agent outputs."""
    from agents.match_score_agent import MatchScoreAgent
    from agents.price_comparison_agent import PriceComparisonAgent
    from agents.recommendation_agent import RecommendationAgent
    from utils.shopping_session import get_profile_or_empty, get_shopping_state, save_shopping_state, sync_chat_gifts

    profile = get_profile_or_empty()
    state = get_shopping_state()
    ollama = current_app.extensions.get("ollama")

    gifts = state.get("gifts")
    if not gifts:
        gifts = RecommendationAgent(ollama=ollama).run(
            profile or {"gift_types": ["Practical"], "budget": 2000},
            limit=10,
        )
        gifts = MatchScoreAgent(ollama=ollama).score_gifts(profile or {}, gifts)
        state["gifts"] = gifts
        if gifts:
            state["match"] = gifts[0].get("match_score")
        save_shopping_state(state)
        sync_chat_gifts(gifts)

    if not state.get("prices") and gifts:
        state["prices"] = PriceComparisonAgent(ollama=ollama).run(
            gifts[:5],
            budget=profile.get("budget"),
        )
        save_shopping_state(state)

    match = state.get("match") or (gifts[0].get("match_score") if gifts else None)
    if not match and profile:
        match = MatchScoreAgent(ollama=ollama).run(profile)

    nearest = None
    shops_payload = state.get("shops") or {}
    shop_list = shops_payload.get("shops") or []
    if shop_list:
        nearest = shop_list[0]

    best_deal = None
    for comp in state.get("prices") or []:
        links = comp.get("shopping_links") or []
        for link in links:
            if "Lowest Price" in (link.get("badges") or []):
                best_deal = {
                    "gift": comp.get("gift_name"),
                    "platform": link.get("platform"),
                    "price_label": link.get("price_label"),
                    "url": link.get("url"),
                }
                break
        if best_deal:
            break

    estimated_cost = sum(int(g.get("estimated_price") or 0) for g in (gifts or [])[:1])
    checklist = state.get("checklist")
    if checklist:
        estimated_cost = checklist.get("estimated_total") or estimated_cost

    budget = profile.get("budget") or 0
    budget_chart = {
        "affordable": int(budget * 0.3) if budget else 500,
        "mid": int(budget * 0.4) if budget else 1200,
        "premium": int(budget * 0.3) if budget else 2000,
    }

    return render_template(
        "dashboard.html",
        profile=profile,
        gifts=gifts or [],
        match=match,
        shops=shops_payload,
        nearest_shop=nearest,
        prices=state.get("prices") or [],
        best_deal=best_deal,
        checklist=checklist,
        wrapping=state.get("wrapping"),
        greeting=state.get("greeting"),
        countdown=state.get("countdown"),
        estimated_cost=estimated_cost,
        budget_chart=budget_chart,
        interview_complete=bool(profile),
    )


@gift_bp.route("/recommendations")
def recommendations() -> Any:
    """Scored gift recommendations from the interview profile."""
    from agents.match_score_agent import MatchScoreAgent
    from agents.recommendation_agent import RecommendationAgent
    from utils.shopping_session import get_profile_or_empty, get_shopping_state, save_shopping_state, sync_chat_gifts

    profile = get_profile_or_empty()
    state = get_shopping_state()
    if not profile:
        flash("Complete the AI interview first for personalised recommendations.", "info")
    gifts = state.get("gifts")
    if not gifts:
        ollama = current_app.extensions.get("ollama")
        gifts = RecommendationAgent(ollama=ollama).run(
            profile or {"gift_types": ["Practical"], "budget": 2000},
            limit=10,
        )
        gifts = MatchScoreAgent(ollama=ollama).score_gifts(profile or {}, gifts)
        state["gifts"] = gifts
        if gifts:
            state["match"] = gifts[0].get("match_score")
        save_shopping_state(state)
        sync_chat_gifts(gifts)
    return render_template("recommendations.html", gifts=gifts, profile=profile)


@gift_bp.route("/comparison")
def comparison() -> Any:
    """Redirect gift comparison toward online price comparison for now."""
    return redirect(url_for("shopping.prices"))
