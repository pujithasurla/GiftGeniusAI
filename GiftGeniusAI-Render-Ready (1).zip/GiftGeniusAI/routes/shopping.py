"""Shopping tools routes: shops, prices, checklist, wrapping, greeting, countdown."""

from __future__ import annotations

from typing import Any

from flask import (
    Blueprint,
    Response,
    current_app,
    flash,
    redirect,
    render_template,
    request,
    url_for,
)

from agents.checklist_agent import ChecklistAgent
from agents.greeting_card_agent import GreetingCardAgent
from agents.match_score_agent import MatchScoreAgent
from agents.price_comparison_agent import PriceComparisonAgent
from agents.recommendation_agent import RecommendationAgent
from agents.shop_locator_agent import ShopLocatorAgent
from agents.wrapping_agent import WrappingAgent
from utils.logger import get_logger
from utils.shopping_session import (
    get_profile_or_empty,
    get_shopping_state,
    save_shopping_state,
    sync_chat_gifts,
)

shopping_bp = Blueprint("shopping", __name__, url_prefix="/gift")
logger = get_logger("routes.shopping")


def _ollama():
    return current_app.extensions.get("ollama")


def _ensure_gifts(profile: dict[str, Any]) -> list[dict[str, Any]]:
    state = get_shopping_state()
    if state.get("gifts"):
        return state["gifts"]
    agent = RecommendationAgent(ollama=_ollama())
    gifts = agent.run(profile or {"gift_types": ["Practical"], "budget": 2000}, limit=10)
    matcher = MatchScoreAgent(ollama=_ollama())
    gifts = matcher.score_gifts(profile or {}, gifts)
    state["gifts"] = gifts
    if gifts:
        state["match"] = gifts[0].get("match_score")
    save_shopping_state(state)
    sync_chat_gifts(gifts)
    return gifts


@shopping_bp.route("/shops", methods=["GET", "POST"])
def shops() -> Any:
    """Smart Gift Shop Locator."""
    state = get_shopping_state()
    profile = get_profile_or_empty()
    result = state.get("shops")
    sort_by = request.values.get("sort_by", (result or {}).get("sort_by") or "nearest")

    if request.method == "POST":
        agent = ShopLocatorAgent(ollama=_ollama())
        result = agent.run(
            current_location=(request.form.get("current_location") or "").strip() or None,
            city=(request.form.get("city") or "").strip() or None,
            state=(request.form.get("state") or "").strip() or None,
            country=(request.form.get("country") or "").strip() or None,
            sort_by=sort_by,
            limit=10,
        )
        state["shops"] = result
        save_shopping_state(state)
        if not result.get("ok"):
            flash(result.get("error") or "Could not find shops.", "warning")
        elif not result.get("shops"):
            flash(result.get("data_note") or "No shops found nearby.", "info")
        else:
            flash(f"Found {result.get('count', 0)} nearby shops.", "success")
        return redirect(url_for("shopping.shops", sort_by=sort_by))

    if result and request.args.get("sort_by") and result.get("shops"):
        agent = ShopLocatorAgent(ollama=_ollama())
        resorted = agent.sort_shops(list(result["shops"]), sort_by)[:10]
        result = dict(result)
        result["shops"] = resorted
        result["sort_by"] = sort_by
        state["shops"] = result
        save_shopping_state(state)

    default_city = (profile.get("location") or "").split(",")[0].strip() if profile.get("location") else ""
    return render_template(
        "shops.html",
        result=result,
        sort_by=sort_by,
        categories=ShopLocatorAgent.CATEGORIES,
        default_city=default_city,
        profile=profile,
    )


@shopping_bp.route("/prices", methods=["GET", "POST"])
def prices() -> Any:
    """Online price comparison for recommended gifts."""
    profile = get_profile_or_empty()
    state = get_shopping_state()
    gifts = _ensure_gifts(profile)

    if request.method == "POST" or not state.get("prices"):
        agent = PriceComparisonAgent(ollama=_ollama())
        comparisons = agent.run(gifts, budget=profile.get("budget"))
        state["prices"] = comparisons
        save_shopping_state(state)
        if request.method == "POST":
            flash("Price estimates refreshed. All figures are labelled estimates.", "success")
            return redirect(url_for("shopping.prices"))

    return render_template(
        "prices.html",
        comparisons=state.get("prices") or [],
        profile=profile,
        platforms=PriceComparisonAgent.PLATFORMS,
    )


@shopping_bp.route("/checklist", methods=["GET", "POST"])
def checklist() -> Any:
    """Shopping checklist generator."""
    profile = get_profile_or_empty()
    state = get_shopping_state()
    gifts = _ensure_gifts(profile)
    top_gift = gifts[0] if gifts else {"name": "Gift Item", "estimated_price": profile.get("budget") or 0}
    agent = ChecklistAgent(ollama=_ollama())

    if request.method == "POST":
        action = request.form.get("action") or "generate"
        if action == "generate":
            checklist_data = agent.run(
                gift_name=request.form.get("gift_name") or top_gift.get("name"),
                gift_cost=int(request.form.get("gift_cost") or top_gift.get("estimated_price") or 0),
                occasion=profile.get("occasion"),
                include_extras=True,
            )
            state["checklist"] = checklist_data
            save_shopping_state(state)
            flash("Checklist generated and saved to your session.", "success")
        elif action == "save":
            current = state.get("checklist") or agent.run(
                gift_name=top_gift.get("name"),
                gift_cost=top_gift.get("estimated_price"),
                occasion=profile.get("occasion"),
            )
            purchased = request.form.getlist("purchased")
            state["checklist"] = agent.apply_checks(current, purchased)
            save_shopping_state(state)
            flash("Checklist saved.", "success")
        return redirect(url_for("shopping.checklist"))

    checklist_data = state.get("checklist")
    if not checklist_data:
        checklist_data = agent.run(
            gift_name=top_gift.get("name"),
            gift_cost=top_gift.get("estimated_price"),
            occasion=profile.get("occasion"),
        )
        state["checklist"] = checklist_data
        save_shopping_state(state)

    return render_template("checklist.html", checklist=checklist_data, profile=profile)


@shopping_bp.route("/checklist/download")
def checklist_download() -> Response:
    """Download checklist as a text file."""
    state = get_shopping_state()
    checklist_data = state.get("checklist")
    if not checklist_data:
        flash("Generate a checklist first.", "warning")
        return redirect(url_for("shopping.checklist"))
    agent = ChecklistAgent(ollama=_ollama())
    text = agent.to_plaintext(checklist_data)
    return Response(
        text,
        mimetype="text/plain",
        headers={"Content-Disposition": "attachment; filename=giftgenius-checklist.txt"},
    )


@shopping_bp.route("/wrapping", methods=["GET", "POST"])
def wrapping() -> Any:
    """Gift wrapping design recommendations."""
    profile = get_profile_or_empty()
    state = get_shopping_state()
    agent = WrappingAgent(ollama=_ollama())
    themes = agent.available_themes()

    if request.method == "POST":
        theme = request.form.get("theme") or "Birthday"
        result = agent.run(
            theme,
            recipient_name=profile.get("recipient_name"),
            occasion=profile.get("occasion"),
        )
        state["wrapping"] = result
        save_shopping_state(state)
        flash(f"{theme} wrapping plan ready.", "success")
        return redirect(url_for("shopping.wrapping"))

    result = state.get("wrapping")
    return render_template(
        "wrapping.html",
        themes=themes,
        result=result,
        profile=profile,
        selected_theme=(result or {}).get("theme") or profile.get("occasion") or "Birthday",
    )


@shopping_bp.route("/greeting", methods=["GET", "POST"])
def greeting() -> Any:
    """Personalized greeting card generator."""
    profile = get_profile_or_empty()
    state = get_shopping_state()
    agent = GreetingCardAgent(ollama=_ollama())

    if request.method == "POST":
        result = agent.run(
            tone=request.form.get("tone") or "Birthday Wishes",
            recipient_name=request.form.get("recipient_name") or profile.get("recipient_name"),
            occasion=request.form.get("occasion") or profile.get("occasion"),
            relationship=request.form.get("relationship") or profile.get("relationship"),
            sender_name=(request.form.get("sender_name") or "").strip() or "Me",
        )
        state["greeting"] = result
        save_shopping_state(state)
        flash("Greeting messages generated.", "success")
        return redirect(url_for("shopping.greeting"))

    return render_template(
        "greeting.html",
        tones=GreetingCardAgent.TONES,
        result=state.get("greeting"),
        profile=profile,
    )


@shopping_bp.route("/greeting/download")
def greeting_download() -> Response:
    """Download greeting card text."""
    result = (get_shopping_state().get("greeting") or {})
    if not result:
        flash("Generate a greeting first.", "warning")
        return redirect(url_for("shopping.greeting"))
    body = (
        f"GiftGenius AI Greeting Card\n"
        f"Tone: {result.get('tone')}\n"
        f"To: {result.get('recipient_name')}\n\n"
        f"SHORT\n{result.get('short')}\n\n"
        f"MEDIUM\n{result.get('medium')}\n\n"
        f"LONG\n{result.get('long')}\n"
    )
    return Response(
        body,
        mimetype="text/plain",
        headers={"Content-Disposition": "attachment; filename=giftgenius-greeting.txt"},
    )


@shopping_bp.route("/countdown", methods=["GET", "POST"])
def countdown() -> Any:
    """Occasion countdown with AI shopping suggestions."""
    profile = get_profile_or_empty()
    state = get_shopping_state()

    if request.method == "POST":
        occasion_date = (request.form.get("occasion_date") or "").strip()
        occasion_label = (
            request.form.get("occasion_label")
            or profile.get("occasion")
            or "Celebration"
        )
        if not occasion_date:
            flash("Please choose an occasion date.", "warning")
            return redirect(url_for("shopping.countdown"))
        state["countdown"] = {
            "occasion_date": occasion_date,
            "occasion_label": occasion_label,
            "saved_at": None,
        }
        save_shopping_state(state)
        flash("Countdown saved.", "success")
        return redirect(url_for("shopping.countdown"))

    return render_template(
        "countdown.html",
        countdown=state.get("countdown"),
        profile=profile,
    )
