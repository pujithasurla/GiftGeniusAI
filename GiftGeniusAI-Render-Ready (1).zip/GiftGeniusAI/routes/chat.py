"""AI Gift Advisor / shopping assistant routes."""

from __future__ import annotations

from typing import Any

from flask import Blueprint, current_app, redirect, render_template, request, url_for

from agents.chat_agent import ChatAgent
from utils.shopping_session import (
    append_chat_message,
    get_chat_memory,
    get_profile_or_empty,
    get_shopping_state,
)

chat_bp = Blueprint("chat", __name__, url_prefix="/chat")


@chat_bp.route("/", methods=["GET", "POST"])
def chat_home() -> Any:
    """Conversational shopping assistant with session memory."""
    profile = get_profile_or_empty()
    memory = get_chat_memory()
    shopping = get_shopping_state()
    if shopping.get("gifts"):
        memory["gifts"] = shopping["gifts"]

    if request.method == "POST":
        action = request.form.get("action")
        
        # Handle clear chat action
        if action == "clear":
            from utils.shopping_session import save_chat_memory
            save_chat_memory({"messages": [], "last_intent": None, "last_action": None})
            return redirect(url_for("chat.chat_home"))
        
        message = (request.form.get("message") or "").strip()
        if message:
            append_chat_message("user", message)
            agent = ChatAgent(ollama=current_app.extensions.get("ollama"))
            result = agent.run(message, memory=memory, profile=profile)
            append_chat_message("assistant", result["reply"])
            memory = get_chat_memory()
            memory["last_intent"] = result.get("intent")
            memory["last_action"] = result.get("action")
            from utils.shopping_session import save_chat_memory

            save_chat_memory(memory)
            if result.get("action") and request.form.get("follow_action") == "1":
                return redirect(result["action"])
        return redirect(url_for("chat.chat_home"))

    return render_template(
        "chat.html",
        messages=memory.get("messages") or [],
        profile=profile,
        last_action=memory.get("last_action"),
        suggestions=[
            "Where can I buy this gift?",
            "Show nearby gift shops.",
            "Show online prices.",
            "Suggest cheaper alternatives.",
            "Suggest luxury alternatives.",
            "Suggest handmade gifts.",
            "Find gifts under ₹500.",
            "Suggest personalized gifts.",
            "Compare Amazon and Flipkart prices.",
            "Generate shopping checklist.",
            "Generate greeting card.",
            "Generate wrapping ideas.",
        ],
    )
