"""Primary public pages: home and navigation destinations."""

from __future__ import annotations

from flask import Blueprint, current_app, render_template

main_bp = Blueprint("main", __name__)


@main_bp.app_context_processor
def inject_globals() -> dict[str, str]:
    """Expose shared template variables on every page."""
    return {
        "app_name": current_app.config.get("APP_NAME", "GiftGenius AI"),
    }


@main_bp.route("/")
def index() -> str:
    """Render the marketing landing page."""
    modes = [
        {
            "title": "Find the Perfect Gift",
            "description": "Answer a guided interview and let multi-agent AI craft personalized recommendations.",
            "href": "/gift/interview",
            "icon": "bi-gift",
            "cta": "Start Interview",
        },
        {
            "title": "Explore Occasions",
            "description": "Browse birthday, wedding, festival, and celebration gift ideas tailored to the moment.",
            "href": "/gift/occasions",
            "icon": "bi-calendar-heart",
            "cta": "Browse Occasions",
        },
        {
            "title": "AI Gift Advisor",
            "description": "Chat with an intelligent advisor for budget, niche, and last-minute gift help.",
            "href": "/chat",
            "icon": "bi-chat-dots",
            "cta": "Open Advisor",
        },
        {
            "title": "Recommendation Dashboard",
            "description": "Review scores, budget splits, and your shortlisted gifts in one place.",
            "href": "/gift/dashboard",
            "icon": "bi-graph-up-arrow",
            "cta": "View Dashboard",
        },
    ]
    return render_template("index.html", modes=modes)
